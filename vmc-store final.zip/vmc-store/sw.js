/* VMC – Service Worker: تسريع الزيارات المتكررة + عمل أساسي دون اتصال */
const V = 'vmc-v8';
self.addEventListener('install', e => { self.skipWaiting(); e.waitUntil(caches.open(V).then(c => c.addAll(['/', '/assets/style.css', '/assets/data.js', '/assets/app.js']).catch(() => {}))); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== V).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const r = e.request, u = new URL(r.url);
  if (r.method !== 'GET' || u.origin !== location.origin || u.pathname.startsWith('/api/') || u.pathname === '/admin.html' || u.pathname.startsWith('/assets/admin')) return;
  if (/^\/assets\/(img|uploads)\//.test(u.pathname)) {                         // صور: الكاش أولاً
    e.respondWith(caches.match(r).then(m => m || fetch(r).then(x => { if (x.ok) { const c = x.clone(); caches.open(V).then(ca => ca.put(r, c)); } return x; })));
  } else if (/\.(js|css)$/.test(u.pathname)) {                                  // سكربت/ستايل: عرض فوري ثم تحديث
    e.respondWith(caches.open(V).then(ca => ca.match(r).then(m => { const n = fetch(r).then(x => { if (x.ok) ca.put(r, x.clone()); return x; }).catch(() => m); return m || n; })));
  } else if (r.mode === 'navigate') {                                           // صفحات: الشبكة أولاً ثم الكاش
    e.respondWith(fetch(r).then(x => { if (x.ok) { const c = x.clone(); caches.open(V).then(ca => ca.put(r, c)); } return x; }).catch(() => caches.match(r).then(m => m || caches.match('/'))));
  }
});
