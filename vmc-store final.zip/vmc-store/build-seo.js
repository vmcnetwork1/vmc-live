/* VMC – مولّد السيو: sitemap.xml + robots.txt + صفحات منتجات ثابتة (3 لغات)
   التشغيل:  node build-seo.js            (يقرأ data/store.json إن وُجد)
   يُستدعى تلقائياً من server.js عند حفظ المنتجات. */
const fs = require('fs');
const path = require('path');
const D = require('./assets/data.js');

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const jsonLd = o => JSON.stringify(o).replace(/</g, '\\u003c');
const LANGS = ['ar', 'fr', 'en'];
const LOCALE = { ar: 'ar_MA', fr: 'fr_MA', en: 'en_US' };

function build(opts = {}) {
  const root = opts.root || __dirname;
  let store = opts.store;
  if (!store) {
    try { store = JSON.parse(fs.readFileSync(path.join(root, 'data', 'store.json'), 'utf8')); } catch (e) { store = {}; }
  }
  const products = store.products || D.VMC_DEFAULT_PRODUCTS;
  const seo = Object.assign({}, D.VMC_DEFAULT_SEO, store.seo || {});
  const site = String(process.env.SITE_URL || (store.seo && store.seo.siteUrl) || D.VMC_CONFIG.siteUrl).replace(/\/+$/, '');
  const abs = u => !u ? site + '/assets/img/og-image.jpg' : /^https?:/.test(u) ? u : site + '/' + u.replace(/^\/+/, '');
  const L = (o, l) => (o && (o[l] || o.fr || o.en || o.ar)) || '';
  const cur = D.VMC_CONFIG.currencyCode;

  fs.mkdirSync(path.join(root, 'p'), { recursive: true });
  // نظّف الصفحات القديمة
  for (const l of LANGS) {
    const dir = path.join(root, 'p', l);
    fs.rmSync(dir, { recursive: true, force: true });
    fs.mkdirSync(dir, { recursive: true });
  }

  const urls = [];
  // الصفحة الرئيسية
  urls.push({ loc: site + '/', alts: LANGS.map(l => [l, site + '/?lang=' + l]), pri: '1.0' });

  for (const p of products) {
    const alts = LANGS.map(l => [l, `${site}/p/${l}/${p.id}.html`]);
    urls.push({ loc: alts[1][1], alts, pri: '0.8' });
    urls.push({ loc: alts[0][1], alts, pri: '0.8' });
    urls.push({ loc: alts[2][1], alts, pri: '0.8' });
    for (const l of LANGS) {
      const name = L(p.name, l), desc = L(p.desc, l);
      const url = `${site}/p/${l}/${p.id}.html`;
      const cat = D.VMC_CATEGORIES.find(c => c.id === p.cat);
      const ld = {
        '@context': 'https://schema.org', '@type': 'Product', name, description: desc,
        image: [abs(p.image)], sku: 'VMC-' + p.id, brand: { '@type': 'Brand', name: 'VMC' },
        category: cat ? L(cat.name, l) : p.cat,
        offers: {
          '@type': 'Offer', url, priceCurrency: cur, price: String(p.price), availability: 'https://schema.org/InStock',
          itemCondition: 'https://schema.org/NewCondition',
          shippingDetails: { '@type': 'OfferShippingDetails', shippingDestination: { '@type': 'DefinedRegion', addressCountry: 'MA' } }
        }
      };
      const crumbs = {
        '@context': 'https://schema.org', '@type': 'BreadcrumbList', itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'VMC', item: site + '/' },
          { '@type': 'ListItem', position: 2, name: cat ? L(cat.name, l) : p.cat, item: site + '/?lang=' + l + '#shop' },
          { '@type': 'ListItem', position: 3, name, item: url }]
      };
      const buy = `${site}/?lang=${l}&product=${p.id}#shop`;
      const t = { ar: 'اطلب الآن – الدفع عند الاستلام', fr: 'Commander – paiement à la livraison', en: 'Order now – cash on delivery' }[l];
      const html = `<!DOCTYPE html>
<html lang="${l}" dir="${l === 'ar' ? 'rtl' : 'ltr'}"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${esc(name)} – ${esc(p.price)} ${esc(cur)} | VMC</title>
<meta name="description" content="${esc(desc)} ${esc(t)}">
<link rel="canonical" href="${esc(url)}">
${alts.map(([al, u]) => `<link rel="alternate" hreflang="${al}" href="${esc(u)}">`).join('\n')}
<link rel="alternate" hreflang="x-default" href="${esc(alts[1][1])}">
<meta property="og:type" content="product"><meta property="og:site_name" content="VMC – Vision Media Commerce">
<meta property="og:title" content="${esc(name)}"><meta property="og:description" content="${esc(desc)}">
<meta property="og:url" content="${esc(url)}"><meta property="og:image" content="${esc(abs(p.image))}"><meta property="og:locale" content="${LOCALE[l]}">
<meta property="product:price:amount" content="${esc(p.price)}"><meta property="product:price:currency" content="${cur}">
<meta name="twitter:card" content="summary_large_image">
<meta name="robots" content="index,follow,max-image-preview:large">
<script type="application/ld+json">${jsonLd(ld)}</script>
<script type="application/ld+json">${jsonLd(crumbs)}</script>
<style>body{font-family:system-ui,'Segoe UI',Tahoma,sans-serif;max-width:720px;margin:40px auto;padding:0 16px;color:#0B1F3B;line-height:1.7}
.p{font-size:80px}.pr{font-size:28px;font-weight:800;color:#E91E63}a.b{display:inline-block;margin-top:16px;padding:14px 28px;border-radius:999px;background:linear-gradient(90deg,#FF3B30,#E91E63,#FF9800);color:#fff;font-weight:800;text-decoration:none}</style>
</head><body>
<a href="${esc(site)}/?lang=${l}">← VMC</a>
<div class="p">${esc(p.emoji || '🛍️')}</div>
<h1>${esc(name)}</h1><p>${esc(desc)}</p>
<div class="pr">${esc(p.price)} ${esc(cur)}</div>
<a class="b" href="${esc(buy)}">${esc(t)}</a>
</body></html>`;
      fs.writeFileSync(path.join(root, 'p', l, p.id + '.html'), html);
    }
  }
  // sitemap بدون تكرار
  const seen = new Set();
  const items = urls.filter(u => !seen.has(u.loc) && seen.add(u.loc));
  const sm = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http://www.w3.org/1999/xhtml">
${items.map(u => `  <url><loc>${esc(u.loc)}</loc>
${u.alts.map(([l, h]) => `    <xhtml:link rel="alternate" hreflang="${l}" href="${esc(h)}"/>`).join('\n')}
    <changefreq>weekly</changefreq><priority>${u.pri}</priority></url>`).join('\n')}
</urlset>
`;
  fs.writeFileSync(path.join(root, 'sitemap.xml'), sm);
  fs.writeFileSync(path.join(root, 'robots.txt'),
    `User-agent: *\nAllow: /\nDisallow: /admin.html\nDisallow: /api/\n\nSitemap: ${site}/sitemap.xml\n`);
  return { pages: products.length * LANGS.length, site };
}

module.exports = { build };
if (require.main === module) console.log('SEO build:', build());
