/* VMC – لوحة التحكم v2
   - مع الخادم (node server.js): البيانات مشتركة ومحفوظة على الخادم + ذكاء اصطناعي حقيقي + إرسال للشركات.
   - بدون خادم (فتح الملف مباشرة): وضع تجريبي يحفظ في المتصفح فقط. */
(function () {
  'use strict';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const lsGet = (k, d) => { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } };
  const lsSet = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { return false; } };
  const MAD = n => '\u200E' + (n || 0).toLocaleString('fr-FR') + '\u00A0MAD\u200E';
  const STATUS = { new: 'جديد', confirmed: 'مؤكد', shipped: 'تم الشحن', delivered: 'تم التسليم', returned: 'مرتجع', cancelled: 'ملغى' };
  const clone = o => JSON.parse(JSON.stringify(o));

  let API = false, TOKEN = sessionStorage.getItem('vmc_token') || '', tab = 'home';
  const DB = { products: [], lives: [], orders: [], pixels: {}, seo: {}, carriers: [], ai: false };

  /* ================= طبقة البيانات ================= */
  async function req(path, opts = {}) {
    const r = await fetch(path, Object.assign({}, opts, { headers: Object.assign({ 'content-type': 'application/json' }, TOKEN ? { authorization: 'Bearer ' + TOKEN } : {}, opts.headers || {}) }));
    const j = await r.json().catch(() => ({}));
    if (r.status === 401 && TOKEN) { logout(); throw new Error('unauthorized'); }
    if (!r.ok) throw Object.assign(new Error(j.error || r.status), { status: r.status });
    return j;
  }
  async function detect() { try { const r = await fetch('api/health'); const j = await r.json(); API = r.ok && j.ok; DB.ai = !!j.ai; } catch (e) { API = false; } }
  async function loadAll() {
    if (API) {
      const s = await req('api/admin/store');
      Object.assign(DB, { products: s.products, lives: s.lives, pixels: s.pixels, seo: s.seo, carriers: s.carriers });
      DB.orders = await req('api/orders');
    } else {
      DB.products = lsGet('vmc_products', null) || clone(VMC_DEFAULT_PRODUCTS);
      DB.lives = lsGet('vmc_lives', null) || clone(VMC_DEFAULT_LIVES);
      DB.pixels = Object.assign({}, VMC_DEFAULT_PIXELS, lsGet('vmc_pixels', {}));
      DB.seo = Object.assign({}, clone(VMC_DEFAULT_SEO), lsGet('vmc_seo', {}));
      DB.carriers = lsGet('vmc_carriers', null) || clone(VMC_DEFAULT_CARRIERS);
      DB.orders = lsGet('vmc_orders', []);
    }
  }
  async function saveStore(keys) {
    if (API) {
      const body = {}; keys.forEach(k => body[k] = DB[k]);
      const r = await req('api/admin/store', { method: 'PUT', body: JSON.stringify(body) });
      toast('✓ تم الحفظ على الخادم'); return r;
    }
    keys.forEach(k => lsSet('vmc_' + k, DB[k])); toast('✓ حُفظ في هذا المتصفح (وضع تجريبي)');
  }
  async function saveOrder(o, patch) {
    Object.assign(o, patch);
    if (API) await req('api/orders/' + encodeURIComponent(o.id), { method: 'PATCH', body: JSON.stringify(patch) });
    else lsSet('vmc_orders', DB.orders);
  }
  function toast(m) {
    let t = $('#toast'); if (!t) { t = document.createElement('div'); t.id = 'toast'; t.className = 'toast'; document.body.appendChild(t); }
    t.textContent = m; t.classList.add('show'); clearTimeout(toast.t); toast.t = setTimeout(() => t.classList.remove('show'), 2200);
  }
  const fail = e => toast('⚠ ' + (e.message || e));
  const copy = t => { navigator.clipboard.writeText(t).then(() => toast('✓ تم النسخ'), () => toast('تعذّر النسخ')); };

  /* ================= الدخول ================= */
  function show() {
    const on = API ? !!TOKEN : sessionStorage.getItem('vmc_admin') === '1';
    $('#login').style.display = on ? 'none' : 'grid'; $('#app').style.display = on ? 'grid' : 'none';
    $('#mode').textContent = API ? '🟢 متصل بالخادم' + (DB.ai ? ' · AI مفعّل' : ' · AI غير مفعّل') : '🟠 وضع تجريبي (بدون خادم)';
    if (on) loadAll().then(render).catch(fail);
  }
  function logout() { TOKEN = ''; sessionStorage.removeItem('vmc_token'); sessionStorage.removeItem('vmc_admin'); show(); }
  $('#loginForm').addEventListener('submit', async e => {
    e.preventDefault(); $('#loginErr').style.display = 'none';
    try {
      if (API) { const j = await req('api/login', { method: 'POST', body: JSON.stringify({ password: $('#pw').value }) }); TOKEN = j.token; DB.ai = j.ai; sessionStorage.setItem('vmc_token', TOKEN); }
      else if ($('#pw').value === VMC_CONFIG.adminPassword) sessionStorage.setItem('vmc_admin', '1');
      else throw new Error('x');
      show();
    } catch (err) { $('#loginErr').style.display = 'block'; }
  });
  $('#logout').addEventListener('click', logout);
  $$('[data-tab]').forEach(b => b.addEventListener('click', () => { tab = b.dataset.tab; $$('[data-tab]').forEach(x => x.classList.toggle('on', x === b)); render(); }));

  const VIEWS = {};
  function render() { (VIEWS[tab] || VIEWS.home)(); }
  const warnLocal = () => API ? '' : '<div class="warn">⚠ أنت في الوضع التجريبي: التغييرات تُحفظ في هذا المتصفح فقط ولا يراها الزوار. شغّل <b>node server.js</b> للنشر الفعلي.</div>';

  /* ================= نظرة عامة ================= */
  VIEWS.home = function () {
    const o = DB.orders, rev = o.filter(x => x.status !== 'cancelled' && x.status !== 'returned').reduce((s, x) => s + x.total, 0);
    const today = o.filter(x => new Date(x.date).toDateString() === new Date().toDateString()).length;
    const src = {}; o.forEach(x => { const k = (x.utm && x.utm.utm_source) || (x.utm && (x.utm.fbclid && 'facebook' || x.utm.ttclid && 'tiktok' || x.utm.gclid && 'google')) || 'direct'; src[k] = (src[k] || 0) + 1; });
    $('#main').innerHTML = `<h1>📊 نظرة عامة</h1>${warnLocal()}
      <div class="stats">
        <div class="stat"><b>${o.length}</b><span>إجمالي الطلبات</span></div>
        <div class="stat"><b>${today}</b><span>طلبات اليوم</span></div>
        <div class="stat"><b>${o.filter(x => x.status === 'new').length}</b><span>بانتظار التأكيد</span></div>
        <div class="stat"><b>${MAD(rev)}</b><span>رقم المعاملات</span></div>
        <div class="stat"><b>${DB.products.length}</b><span>المنتجات</span></div>
      </div>
      <div class="panel"><h2>مصادر الطلبات</h2>${Object.keys(src).length ? Object.entries(src).map(([k, v]) => `<span class="pill" style="margin:3px">${esc(k)}: <b>${v}</b></span>`).join('') : '<p class="note">لا توجد بيانات بعد. أضف معاملات UTM لروابط إعلاناتك لتظهر هنا.</p>'}</div>
      <div class="panel"><h2>آخر الطلبات</h2>${o.length ? `<div class="tw"><table><tr><th>الرقم</th><th>العميل</th><th>المدينة</th><th>المجموع</th><th>الحالة</th></tr>${o.slice(0, 6).map(x => `<tr><td>${esc(x.id)}</td><td>${esc(x.name)}</td><td>${esc(x.city)}</td><td>${MAD(x.total)}</td><td><span class="pill ${esc(x.status)}">${STATUS[x.status] || x.status}</span></td></tr>`).join('')}</table></div>` : '<p class="note">لا توجد طلبات بعد.</p>'}</div>`;
  };

  /* ================= المنتجات ================= */
  function fileToDataURL(file, max = 1000, type = 'image/jpeg', q = .86) {
    return new Promise((res, rej) => {
      const img = new Image(), u = URL.createObjectURL(file);
      img.onload = () => { const k = Math.min(1, max / Math.max(img.width, img.height)); const c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k); const x = c.getContext('2d'); if (type === 'image/jpeg') { x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); } x.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u); res(c.toDataURL(type, q)); };
      img.onerror = () => rej(new Error('صورة غير صالحة')); img.src = u;
    });
  }
  async function storeImage(dataUrl) {
    if (API) return (await req('api/upload', { method: 'POST', body: JSON.stringify({ dataUrl }) })).url;
    return dataUrl;
  }
  VIEWS.products = function () {
    const p = DB.products;
    $('#main').innerHTML = `<h1>🛍️ المنتجات</h1>${warnLocal()}
      <div class="panel"><h2>إضافة منتج</h2>
        <form class="form" id="pf">
          <div class="field"><label>الاسم (عربي)</label><input name="ar" required></div>
          <div class="field"><label>Nom (FR)</label><input name="fr" required></div>
          <div class="field"><label>Name (EN)</label><input name="en" required></div>
          <div class="field"><label>الوصف (عربي)</label><input name="dar"></div>
          <div class="field"><label>Description (FR)</label><input name="dfr"></div>
          <div class="field"><label>Description (EN)</label><input name="den"></div>
          <div class="field"><label>القسم</label><select name="cat">${VMC_CATEGORIES.map(c => `<option value="${c.id}">${c.icon} ${c.name.ar}</option>`).join('')}</select></div>
          <div class="field"><label>السعر (MAD)</label><input name="price" type="number" min="1" required></div>
          <div class="field"><label>السعر القديم (اختياري)</label><input name="old" type="number" min="0"></div>
          <div class="field"><label>إيموجي</label><input name="emoji" value="🛍️" maxlength="4"></div>
          <div class="field"><label>صورة المنتج (ملف)</label><input name="file" type="file" accept="image/*"></div>
          <div class="field"><label>أو رابط صورة</label><input name="image" type="url" placeholder="https://…"></div>
          <div class="field"><label>معروض في البث؟</label><select name="live"><option value="0">لا</option><option value="1">نعم</option></select></div>
          <div class="full"><button class="btn primary">+ إضافة</button></div>
        </form></div>
      <div class="panel tw"><h2>القائمة (${p.length})</h2><table>
        <tr><th></th><th>الاسم</th><th>القسم</th><th>السعر</th><th>بث</th><th></th></tr>
        ${p.map(x => `<tr><td style="font-size:24px">${x.image ? `<img src="${esc(x.image)}" style="width:44px;height:44px;object-fit:cover;border-radius:8px">` : esc(x.emoji || '🛍️')}</td><td>${esc(x.name.ar)}<br><small>${esc(x.name.fr)}</small></td>
          <td>${esc(((VMC_CATEGORIES.find(c => c.id === x.cat) || {}).name || {}).ar || x.cat)}</td>
          <td><input type="number" value="${x.price}" data-price="${x.id}" class="st" style="width:90px"></td>
          <td><input type="checkbox" data-live="${x.id}" ${x.live ? 'checked' : ''}></td>
          <td><button class="mini-btn" data-ai="${x.id}">✨ AI</button><button class="mini-btn red" data-del="${x.id}">حذف</button></td></tr>`).join('')}
      </table></div>`;
    $('#pf').addEventListener('submit', async e => {
      e.preventDefault();
      try {
        const fd = new FormData(e.target), f = Object.fromEntries(fd); let image = f.image || '';
        const file = fd.get('file'); if (file && file.size) image = await storeImage(await fileToDataURL(file));
        DB.products.push({ id: Date.now() % 1e9, cat: f.cat, emoji: f.emoji || '🛍️', image, price: +f.price, old: +f.old || 0, live: f.live === '1', name: { ar: f.ar, fr: f.fr, en: f.en }, desc: { ar: f.dar, fr: f.dfr, en: f.den } });
        await saveStore(['products']); VIEWS.products();
      } catch (err) { fail(err); }
    });
    $$('[data-del]').forEach(b => b.onclick = async () => { if (confirm('حذف المنتج؟')) { DB.products = DB.products.filter(x => x.id !== +b.dataset.del); try { await saveStore(['products']); } catch (e) { fail(e); } VIEWS.products(); } });
    $$('[data-price]').forEach(i => i.onchange = () => { DB.products.find(x => x.id === +i.dataset.price).price = +i.value || 1; saveStore(['products']).catch(fail); });
    $$('[data-live]').forEach(i => i.onchange = () => { DB.products.find(x => x.id === +i.dataset.live).live = i.checked; saveStore(['products']).catch(fail); });
    $$('[data-ai]').forEach(b => b.onclick = () => { AI_STATE.pid = +b.dataset.ai; tab = 'ai'; $$('[data-tab]').forEach(x => x.classList.toggle('on', x.dataset.tab === 'ai')); render(); });
  };

  /* ================= الطلبات + التوصيل ================= */
  const carrierName = id => ((DB.carriers.find(c => c.id === id) || {}).name) || id || '';
  const trackUrl = o => { const c = DB.carriers.find(x => x.id === o.carrier); return c && c.tracking && o.tracking ? c.tracking.replace('{n}', encodeURIComponent(o.tracking)) : ''; };
  const waCust = o => {
    const t = trackUrl(o);
    const msg = `مرحباً ${o.name} 👋\nطلبك ${o.id} من VMC ${o.status === 'shipped' ? 'في الطريق إليك 🚚' : 'تم تأكيده ✅'}\nالمبلغ عند الاستلام: ${MAD(o.total)}${o.tracking ? '\nرقم التتبع: ' + o.tracking : ''}${t ? '\n' + t : ''}\nشكراً لثقتك!`;
    return 'https://wa.me/' + String(o.phone).replace(/^0/, '212').replace(/^\+|^00/, '').replace(/\D/g, '') + '?text=' + encodeURIComponent(msg);
  };
  function printWaybill(o) {
    const w = window.open('', '_blank'); if (!w) return;
    w.document.write(`<!doctype html><meta charset=utf-8><title>${esc(o.id)}</title><body style="font-family:Arial;padding:24px;max-width:480px"><h2>VMC – ${esc(o.id)}</h2><p><b>${esc(o.name)}</b><br>${esc(o.phone)}<br>${esc(o.city)} – ${esc(o.address)}</p><hr>${o.items.map(i => esc(i.name) + ' × ' + i.qty).join('<br>')}<hr><h1>COD: ${MAD(o.total)}</h1><p>${esc(o.notes || '')}</p><p>${esc(carrierName(o.carrier))} ${esc(o.tracking || '')}</p><script>print()<\/script>`);
    w.document.close();
  }
  VIEWS.orders = function () {
    const enabled = DB.carriers.filter(c => c.enabled);
    const list = DB.orders;
    $('#main').innerHTML = `<h1>📦 الطلبات</h1>${warnLocal()}
      <div class="panel"><div class="sec-t"><button class="mini-btn" id="csv">⬇ CSV (الكل)</button>
        <select id="csvCar" class="st"><option value="">تصدير حسب الشركة…</option>${enabled.map(c => `<option value="${esc(c.id)}">${esc(c.name)}</option>`).join('')}</select>
        <small class="note">الملف جاهز للرفع في لوحات شركات التوصيل (الاسم، الهاتف، المدينة، العنوان، المبلغ عند الاستلام).</small></div><br>
      ${list.length ? `<div class="tw"><table><tr><th>الطلب</th><th>العميل</th><th>المنتجات</th><th>المجموع</th><th>الحالة</th><th>التوصيل</th><th></th></tr>
      ${list.map(o => `<tr><td><b>${esc(o.id)}</b><br><small>${new Date(o.date).toLocaleString('fr-FR')}</small></td>
        <td>${esc(o.name)}<br><small dir="ltr">${esc(o.phone)}</small><br><small>${esc(o.city)} – ${esc(o.address)}</small></td>
        <td>${o.items.map(i => `${esc(i.name)} ×${i.qty}`).join('<br>')}</td>
        <td><b>${MAD(o.total)}</b><br><small>COD</small></td>
        <td><select class="st" data-st="${esc(o.id)}">${Object.keys(STATUS).map(k => `<option value="${k}" ${o.status === k ? 'selected' : ''}>${STATUS[k]}</option>`).join('')}</select></td>
        <td><select class="st" data-car="${esc(o.id)}"><option value="">—</option>${DB.carriers.map(c => `<option value="${esc(c.id)}" ${o.carrier === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}</select><br>
          <input class="st" placeholder="رقم التتبع" value="${esc(o.tracking || '')}" data-trk="${esc(o.id)}" style="margin-top:4px">
          ${trackUrl(o) ? `<br><a href="${esc(trackUrl(o))}" target="_blank" rel="noopener" style="font-size:12px;color:var(--red)">تتبّع ↗</a>` : ''}</td>
        <td><a class="mini-btn ok" href="${esc(waCust(o))}" target="_blank" rel="noopener">💬 واتساب</a>
          <button class="mini-btn" data-print="${esc(o.id)}">🖨</button>
          ${API ? `<button class="mini-btn red" data-ship="${esc(o.id)}">🚚 إرسال للشركة</button>` : ''}</td></tr>`).join('')}</table></div>` : '<p class="note">لا توجد طلبات بعد.</p>'}</div>`;
    const by = id => DB.orders.find(o => o.id === id);
    $$('[data-st]').forEach(s => s.onchange = () => saveOrder(by(s.dataset.st), { status: s.value }).catch(fail));
    $$('[data-car]').forEach(s => s.onchange = () => saveOrder(by(s.dataset.car), { carrier: s.value }).then(VIEWS.orders).catch(fail));
    $$('[data-trk]').forEach(i => i.onchange = () => saveOrder(by(i.dataset.trk), { tracking: i.value.trim() }).then(VIEWS.orders).catch(fail));
    $$('[data-print]').forEach(b => b.onclick = () => printWaybill(by(b.dataset.print)));
    $$('[data-ship]').forEach(b => b.onclick = async () => {
      const o = by(b.dataset.ship); if (!o.carrier) return toast('اختر شركة التوصيل أولاً');
      try {
        const r = await req('api/orders/' + encodeURIComponent(o.id) + '/ship', { method: 'POST', body: JSON.stringify({ carrier: o.carrier }) });
        if (r.reason === 'no_webhook') toast('لم يُضبط Webhook لهذه الشركة (تبويب شركات التوصيل). استعمل CSV أو أدخل رقم التتبع يدوياً.');
        else { Object.assign(o, r.order); toast(r.dispatched ? '✓ أُرسل للشركة' : '⚠ ردّت الشركة بخطأ ' + r.status); VIEWS.orders(); }
      } catch (e) { fail(e); }
    });
    const csv = rows => { const t = '﻿' + rows.map(r => r.map(c => '"' + String(c == null ? '' : c).replace(/"/g, '""') + '"').join(',')).join('\n'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([t], { type: 'text/csv;charset=utf-8' })); a.download = 'vmc-orders.csv'; a.click(); };
    $('#csv').onclick = () => csv([['id', 'date', 'name', 'phone', 'city', 'address', 'items', 'cod_total', 'status', 'carrier', 'tracking']].concat(DB.orders.map(o => [o.id, o.date, o.name, o.phone, o.city, o.address, o.items.map(i => i.name + ' x' + i.qty).join(' | '), o.total, o.status, o.carrier, o.tracking])));
    $('#csvCar').onchange = e => { const id = e.target.value; if (!id) return; csv([['reference', 'name', 'phone', 'city', 'address', 'cod_amount', 'products', 'notes']].concat(DB.orders.filter(o => o.carrier === id && (o.status === 'new' || o.status === 'confirmed')).map(o => [o.id, o.name, o.phone, o.city, o.address, o.total, o.items.map(i => i.name + ' x' + i.qty).join(' | '), o.notes]))); e.target.value = ''; };
  };

  VIEWS.delivery = function () {
    $('#main').innerHTML = `<h1>🚚 شركات التوصيل</h1>${warnLocal()}
      <div class="panel"><h2>الشركات</h2>
        <p class="note">فعّل الشركات التي تتعامل معها. لإرسال الطلبات تلقائياً ضع <b>Webhook URL</b> (https) خاصاً بحسابك — من واجهة API الرسمية للشركة أو عبر وسيط مثل Make / Zapier / n8n — وسيصلها JSON بالمرجع والعميل والعنوان والمبلغ عند الاستلام. وإلا استعمل تصدير CSV وأدخل رقم التتبع يدوياً.</p><br>
        <div class="tw"><table><tr><th>تفعيل</th><th>الشركة</th><th>قالب رابط التتبع ({n})</th>${API ? '<th>Webhook URL</th><th>مفتاح API</th>' : ''}</tr>
        ${DB.carriers.map((c, i) => `<tr><td><input type="checkbox" data-ce="${i}" ${c.enabled ? 'checked' : ''}></td><td><b>${esc(c.name)}</b></td>
          <td><input class="st" style="max-width:260px;width:100%" data-ct="${i}" value="${esc(c.tracking || '')}" placeholder="https://…{n}"></td>
          ${API ? `<td><input class="st" style="max-width:260px;width:100%" data-cw="${i}" value="${esc(c.webhook || '')}" placeholder="https://…"></td><td><input class="st" type="password" data-ck="${i}" value="${esc(c.apiKey || '')}" placeholder="اختياري"></td>` : ''}</tr>`).join('')}</table></div>
        <div class="row-btn"><button class="btn primary" id="saveCar">حفظ</button><button class="btn dark" id="addCar">+ شركة جديدة</button></div>
        <h3>شكل البيانات المُرسلة</h3><pre>{ "reference":"VMC-AB12CD", "cod_amount":449, "currency":"MAD",
  "customer":{"name":"…","phone":"06…","city":"Casablanca","address":"…"},
  "items":[{"id":1,"name":"…","price":449,"qty":1}], "notes":"" }</pre>
        <p class="note">إن أعاد رد الشركة حقلاً باسم tracking أو tracking_number أو waybill يُحفظ تلقائياً كرقم تتبع. تحتاج كل شركة إلى حساب تاجر ومفاتيح API الخاصة بها، وصيغة طلبها قد تختلف عن الصيغة أعلاه.</p></div>`;
    $('#saveCar').onclick = () => {
      $$('[data-ce]').forEach(i => DB.carriers[+i.dataset.ce].enabled = i.checked);
      $$('[data-ct]').forEach(i => DB.carriers[+i.dataset.ct].tracking = i.value.trim());
      $$('[data-cw]').forEach(i => DB.carriers[+i.dataset.cw].webhook = i.value.trim());
      $$('[data-ck]').forEach(i => DB.carriers[+i.dataset.ck].apiKey = i.value.trim());
      saveStore(['carriers']).catch(fail);
    };
    $('#addCar').onclick = () => { const n = prompt('اسم الشركة'); if (n) { DB.carriers.push({ id: 'c' + Date.now().toString(36), name: n.slice(0, 40), tracking: '', enabled: true }); saveStore(['carriers']).then(VIEWS.delivery).catch(fail); } };
  };

  /* ================= البثوث ================= */
  VIEWS.lives = function () {
    const l = DB.lives, p = DB.products;
    $('#main').innerHTML = `<h1>📺 البثوث</h1>${warnLocal()}
      <div class="panel"><h2>إضافة بث</h2><form class="form" id="lf">
        <div class="field"><label>العنوان (عربي)</label><input name="ar" required></div>
        <div class="field"><label>Titre (FR)</label><input name="fr" required></div>
        <div class="field"><label>Title (EN)</label><input name="en" required></div>
        <div class="field"><label>المنصة</label><select name="platform"><option value="youtube">YouTube</option><option value="facebook">Facebook</option><option value="tiktok">TikTok</option><option value="instagram">Instagram</option></select></div>
        <div class="field"><label>رابط البث</label><input name="url" type="url" placeholder="https://youtube.com/live/…"></div>
        <div class="field"><label>الحالة</label><select name="status"><option value="soon">قريباً</option><option value="live">مباشر الآن</option></select></div>
        <div class="field"><label>موعد البث (يظهر في دليل البث)</label><input name="at" type="datetime-local"></div>
        <div class="field full"><label>المنتجات المرتبطة (Ctrl للاختيار المتعدد)</label><select name="products" multiple size="5">${p.map(x => `<option value="${x.id}">${esc(x.emoji || '')} ${esc(x.name.ar)}</option>`).join('')}</select></div>
        <div class="full"><button class="btn primary">+ إضافة</button></div></form>
        <p class="note">روابط YouTube تُعرض داخل الموقع مباشرة؛ بقية المنصات تفتح في نافذة جديدة.</p></div>
      <div class="panel tw"><table><tr><th>المنصة</th><th>العنوان</th><th>الموعد</th><th>الحالة</th><th></th></tr>
      ${l.map(x => `<tr><td>${esc(x.platform)}</td><td>${esc(x.title.ar)}</td><td>${x.at ? new Date(x.at).toLocaleString('fr-FR') : '—'}</td>
        <td><select class="st" data-ls="${x.id}"><option value="soon" ${x.status === 'soon' ? 'selected' : ''}>قريباً</option><option value="live" ${x.status === 'live' ? 'selected' : ''}>مباشر</option></select></td>
        <td><button class="mini-btn red" data-ld="${x.id}">حذف</button></td></tr>`).join('')}</table></div>`;
    $('#lf').addEventListener('submit', e => {
      e.preventDefault(); const fd = new FormData(e.target), f = Object.fromEntries(fd);
      DB.lives.push({ id: Date.now() % 1e9, platform: f.platform, url: f.url || '', status: f.status, at: f.at ? new Date(f.at).toISOString() : '', products: fd.getAll('products').map(Number), title: { ar: f.ar, fr: f.fr, en: f.en } });
      saveStore(['lives']).then(VIEWS.lives).catch(fail);
    });
    $$('[data-ld]').forEach(b => b.onclick = () => { DB.lives = DB.lives.filter(x => x.id !== +b.dataset.ld); saveStore(['lives']).then(VIEWS.lives).catch(fail); });
    $$('[data-ls]').forEach(s => s.onchange = () => { DB.lives.find(x => x.id === +s.dataset.ls).status = s.value; saveStore(['lives']).catch(fail); });
  };

  /* ================= الذكاء الاصطناعي (نصوص) ================= */
  const AI_STATE = { pid: null, last: null };
  const PLATFORMS = ['Meta (Facebook/Instagram)', 'TikTok', 'Instagram Reels', 'Snapchat', 'Google Ads', 'Pinterest'];
  async function aiCall(body) {
    if (!API) throw new Error('local');
    if (!DB.ai) throw new Error('no_key');
    return (await req('api/ai', { method: 'POST', body: JSON.stringify(body) })).result;
  }
  /* قوالب احتياطية عند غياب الخادم أو مفتاح الذكاء الاصطناعي */
  function localDesc(n, feats, fun) {
    const f = feats.length ? feats : [];
    const mk = (l, t) => ({ title: n, short: t.s, long: t.l, bullets: f.length ? f : t.b, seoTitle: (n + ' | VMC').slice(0, 60), seoDesc: t.s.slice(0, 155) });
    return {
      ar: mk('ar', { s: `${n}: ${fun ? 'عرض لا يُفوَّت!' : 'جودة وسعر مناسب'} مع الدفع عند الاستلام.`, l: `${n} اختيار عملي لكل يوم.${f.length ? ' يتميز بـ ' + f.join('، ') + '.' : ''}\nاطلبه الآن وادفع عند الاستلام مع توصيل لجميع مدن المغرب.`, b: ['الدفع عند الاستلام', 'توصيل لجميع مدن المغرب', 'خدمة عملاء عبر واتساب'] }),
      fr: mk('fr', { s: `${n} : ${fun ? 'offre à ne pas manquer !' : 'qualité et bon prix'}, paiement à la livraison.`, l: `${n}, le bon choix au quotidien.${f.length ? ' Points forts : ' + f.join(', ') + '.' : ''}\nCommandez maintenant et payez à la réception, partout au Maroc.`, b: ['Paiement à la livraison', 'Livraison dans tout le Maroc', 'Service client WhatsApp'] }),
      en: mk('en', { s: `${n}: ${fun ? 'a deal you can’t miss!' : 'quality at a fair price'}, cash on delivery.`, l: `${n}, a smart everyday choice.${f.length ? ' Highlights: ' + f.join(', ') + '.' : ''}\nOrder now and pay on delivery anywhere in Morocco.`, b: ['Cash on delivery', 'Delivery across Morocco', 'WhatsApp customer support'] })
    };
  }
  function localAds(n, price, lang, platform) {
    const P = price ? ` ${price} MAD` : '';
    const T = {
      ar: [['فائدة', `✨ اكتشف ${n}`, `${n} بين يديك${P ? ' بسعر' + P : ''}. جودة تستحق التجربة، والدفع عند الاستلام مع توصيل لكل المغرب.`, n, 'اطلب الآن'],
           ['عرض', `🔥 عرض خاص على ${n}`, `لا تفوّت عرض ${n}${P ? ' – فقط' + P : ''}. الكمية محدودة، اطلب الآن وادفع عند الاستلام.`, 'عرض لفترة محدودة', 'تسوّق الآن'],
           ['مشكلة وحل', `🤔 تبحث عن ${n}؟`, `وفّرنا لك ${n} بسهولة: اطلب من هاتفك، نتصل بك للتأكيد، وتدفع عند وصول طلبك.`, 'اطلب من البيت', 'اطلب الآن']],
      fr: [['Bénéfice', `✨ Découvrez ${n}`, `${n}${P ? ' à' + P : ''}. Qualité à tester, paiement à la livraison partout au Maroc.`, n, 'Commander'],
           ['Offre', `🔥 Offre spéciale : ${n}`, `Ne ratez pas ${n}${P ? ' – seulement' + P : ''}. Stock limité, commandez maintenant.`, 'Offre limitée', 'J’en profite'],
           ['Problème/solution', `🤔 Vous cherchez ${n} ?`, `Commandez depuis votre mobile, nous vous appelons pour confirmer, vous payez à la réception.`, 'Commandez de chez vous', 'Commander']],
      en: [['Benefit', `✨ Meet ${n}`, `${n}${P ? ' for' + P : ''}. Worth trying, cash on delivery across Morocco.`, n, 'Order now'],
           ['Offer', `🔥 Special offer: ${n}`, `Don’t miss ${n}${P ? ' – only' + P : ''}. Limited stock, order now and pay on delivery.`, 'Limited-time offer', 'Shop now'],
           ['Problem/solution', `🤔 Looking for ${n}?`, `Order from your phone, we call to confirm, you pay when it arrives.`, 'Order from home', 'Order now']]
    }[lang] || [];
    return T.map(t => ({ angle: t[0], hook: t[1], primary: t[2], headline: t[3], cta: t[4], hashtags: ['#VMC', '#' + (lang === 'ar' ? 'المغرب' : 'Maroc')], creative: 'صورة المنتج على خلفية بألوان VMC + شارة السعر (من تبويب استوديو الإعلانات).', script: `[0-3s] ${t[1]}\n[3-15s] عرض المنتج وأهم مزاياه\n[15-25s] السعر + الدفع عند الاستلام\n[25-30s] ${t[4]} (${platform})` }));
  }
  const resCard = (t, body) => `<div class="res"><h4>${esc(t)}</h4>${esc(body)}<div class="row-btn"><button class="mini-btn" data-cp="${esc(body).replace(/"/g, '&quot;')}">نسخ</button></div></div>`;

  VIEWS.ai = function () {
    const p = DB.products;
    $('#main').innerHTML = `<h1>🤖 الذكاء الاصطناعي</h1>
      ${API ? (DB.ai ? '<div class="good">✓ الذكاء الاصطناعي مفعّل (Claude) — الأوصاف والإعلانات تُولَّد بجودة احترافية.</div>' : '<div class="warn">مفتاح ANTHROPIC_API_KEY غير مضبوط على الخادم، لذلك تُستعمل قوالب جاهزة. أضفه في ملف .env ثم أعد تشغيل الخادم.</div>') : '<div class="warn">وضع تجريبي بدون خادم: تُستعمل قوالب جاهزة. شغّل node server.js وأضف ANTHROPIC_API_KEY لتفعيل الذكاء الاصطناعي الحقيقي.</div>'}
      <div class="panel"><h2>✍️ وصف احترافي + سيو (3 لغات)</h2><div class="form">
        <div class="field"><label>المنتج</label><select id="aiP"><option value="">— إدخال يدوي —</option>${p.map(x => `<option value="${x.id}" ${AI_STATE.pid === x.id ? 'selected' : ''}>${esc(x.name.ar)}</option>`).join('')}</select></div>
        <div class="field"><label>اسم المنتج</label><input id="aiName"></div>
        <div class="field"><label>المميزات (مفصولة بفاصلة)</label><input id="aiFeat" placeholder="خفيف, مقاوم للماء, ضمان سنة"></div>
        <div class="field"><label>النبرة</label><select id="aiTone"><option value="professional">احترافية</option><option value="energetic">حماسية للبث</option><option value="luxury">راقية</option></select></div></div>
        <div class="row-btn"><button class="btn primary" id="aiDesc">✨ توليد الوصف</button></div><div class="cards" id="descOut"></div></div>
      <div class="panel"><h2>📣 نصوص إعلانية</h2><div class="form">
        <div class="field"><label>المنصة</label><select id="adPlat">${PLATFORMS.map(x => `<option>${x}</option>`).join('')}</select></div>
        <div class="field"><label>الهدف</label><select id="adObj"><option value="sales (cash on delivery)">مبيعات (دفع عند الاستلام)</option><option value="traffic to live stream">زيارات للبث المباشر</option><option value="brand awareness">تعريف بالعلامة</option></select></div>
        <div class="field"><label>لغة الإعلان</label><select id="adLang"><option value="ar">العربية</option><option value="fr">Français</option><option value="en">English</option></select></div>
        <div class="field"><label>النبرة</label><select id="adTone"><option value="energetic">حماسية</option><option value="professional">احترافية</option><option value="friendly">ودّية</option></select></div></div>
        <div class="row-btn"><button class="btn primary" id="adGo">🚀 توليد 3 نسخ إعلانية</button></div><div class="cards" id="adOut"></div>
        <p class="note">تأكد من مطابقة الإعلان لسياسات المنصة وعدم ذكر وعود أو خصومات غير حقيقية.</p></div>`;
    const cur = () => { const id = +$('#aiP').value; const x = p.find(y => y.id === id); return { x, name: $('#aiName').value.trim() || (x && x.name.ar) || '', feats: $('#aiFeat').value.split(/[,،]/).map(s => s.trim()).filter(Boolean) }; };
    $('#aiP').onchange = () => { const x = p.find(y => y.id === +$('#aiP').value); if (x) $('#aiName').value = x.name.ar; };
    if (AI_STATE.pid) $('#aiP').onchange();
    $('#aiDesc').onclick = async () => {
      const c = cur(); if (!c.name) return toast('أدخل اسم المنتج');
      $('#descOut').innerHTML = '<div class="res">⏳ جارٍ التوليد…</div>';
      let r, ai = true;
      try { r = await aiCall({ task: 'description', tone: $('#aiTone').value, product: { name: c.name, cat: c.x && c.x.cat, price: c.x && c.x.price, old: c.x && c.x.old, features: c.feats.join(', '), desc: c.x && c.x.desc && c.x.desc.ar } }); }
      catch (e) { ai = false; r = localDesc(c.name, c.feats, $('#aiTone').value === 'energetic'); if (API && DB.ai) toast('⚠ تعذّر الذكاء الاصطناعي: ' + e.message + ' — استُعملت القوالب'); }
      AI_STATE.last = r;
      $('#descOut').innerHTML = ['ar', 'fr', 'en'].map(l => { const d = r[l] || {}; const body = `${d.title || ''}\n\n${d.short || ''}\n\n${d.long || ''}\n\n${(d.bullets || []).map(b => '• ' + b).join('\n')}\n\nSEO title: ${d.seoTitle || ''}\nSEO desc: ${d.seoDesc || ''}`; return resCard(l.toUpperCase() + (ai ? ' · AI' : ' · قالب'), body); }).join('') + (c.x ? `<div class="res"><h4>تطبيق على المنتج</h4>اضغط لحفظ العنوان والوصف القصير بالثلاث لغات في «${esc(c.x.name.ar)}».<div class="row-btn"><button class="mini-btn ok" id="applyDesc">✓ تطبيق وحفظ</button></div></div>` : '');
      $$('[data-cp]').forEach(b => b.onclick = () => copy(b.dataset.cp.replace(/&quot;/g, '"')));
      const ap = $('#applyDesc'); if (ap) ap.onclick = () => { ['ar', 'fr', 'en'].forEach(l => { if (r[l]) { c.x.name[l] = r[l].title || c.x.name[l]; c.x.desc[l] = r[l].short || c.x.desc[l]; } }); saveStore(['products']).catch(fail); };
    };
    $('#adGo').onclick = async () => {
      const c = cur(); if (!c.name) return toast('اختر منتجاً أو أدخل اسمه في القسم أعلاه');
      const lang = $('#adLang').value, platform = $('#adPlat').value;
      $('#adOut').innerHTML = '<div class="res">⏳ جارٍ التوليد…</div>'; let r, ai = true;
      try { r = await aiCall({ task: 'ad', platform, objective: $('#adObj').value, language: lang, tone: $('#adTone').value, product: { name: c.name, cat: c.x && c.x.cat, price: c.x && c.x.price, old: c.x && c.x.old, features: c.feats.join(', '), desc: c.x && c.x.desc && c.x.desc[lang] } }); if (!Array.isArray(r)) throw new Error('bad_ai_output'); }
      catch (e) { ai = false; r = localAds(c.name, c.x && c.x.price, lang, platform); if (API && DB.ai) toast('⚠ ' + e.message + ' — استُعملت القوالب'); }
      $('#adOut').innerHTML = r.map((a, i) => resCard(`نسخة ${i + 1} · ${a.angle || ''}${ai ? ' · AI' : ''}`, `${a.hook || ''}\n\n${a.primary || ''}\n\nHeadline: ${a.headline || ''}\nCTA: ${a.cta || ''}\n${(a.hashtags || []).join(' ')}\n\n🎨 ${a.creative || ''}\n\n🎬 ${a.script || ''}`)).join('');
      $$('[data-cp]').forEach(b => b.onclick = () => copy(b.dataset.cp.replace(/&quot;/g, '"')));
    };
  };

  /* ================= استوديو الإعلانات (Canvas) ================= */
  const FMT = { sq: [1080, 1080, 'مربع 1080×1080 (Feed)'], st: [1080, 1920, 'ستوري/ريلز/TikTok 1080×1920'], ls: [1200, 628, 'أفقي 1200×628 (Link/Google)'] };
  const TPL = { navy: { bg: ['#0B1F3B', '#3a1450', '#E91E63'], fg: '#fff', sub: '#ffd7b0' }, light: { bg: ['#ffffff', '#fff1e6', '#ffd6e6'], fg: '#0B1F3B', sub: '#E91E63' }, fire: { bg: ['#FF3B30', '#E91E63', '#FF9800'], fg: '#fff', sub: '#fff3d6' } };
  const SS = { img: null, imgKey: '' };
  function sharpen(ctx, w, h, amt) {
    const src = ctx.getImageData(0, 0, w, h), out = ctx.createImageData(w, h), s = src.data, d = out.data, k = amt;
    for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
      const i = (y * w + x) * 4;
      for (let c = 0; c < 3; c++) {
        if (x === 0 || y === 0 || x === w - 1 || y === h - 1) { d[i + c] = s[i + c]; continue; }
        const v = s[i + c] * (1 + 4 * k) - k * (s[i - 4 + c] + s[i + 4 + c] + s[i - w * 4 + c] + s[i + w * 4 + c]);
        d[i + c] = v < 0 ? 0 : v > 255 ? 255 : v;
      }
      d[i + 3] = s[i + 3];
    }
    ctx.putImageData(out, 0, 0);
  }
  function enhanced(img, bw, bh, level) {
    const c = document.createElement('canvas'); c.width = Math.max(1, Math.round(bw)); c.height = Math.max(1, Math.round(bh)); const x = c.getContext('2d');
    const k = Math.min(c.width / img.width, c.height / img.height), w = img.width * k, h = img.height * k;
    const f = level / 100; x.filter = `contrast(${1 + .18 * f}) saturate(${1 + .25 * f}) brightness(${1 + .05 * f})`;
    x.imageSmoothingQuality = 'high'; x.drawImage(img, (c.width - w) / 2, (c.height - h) / 2, w, h); x.filter = 'none';
    if (level > 0) sharpen(x, c.width, c.height, .35 * f);
    return c;
  }
  function wrapText(c, text, maxW) { const ws = String(text).split(/\s+/), L = []; let cur = ''; ws.forEach(w => { const t = cur ? cur + ' ' + w : w; if (c.measureText(t).width > maxW && cur) { L.push(cur); cur = w; } else cur = t; }); if (cur) L.push(cur); return L; }
  const isAr = t => /[؀-ۿ]/.test(t);
  function rr(c, x, y, w, h, r) { c.beginPath(); c.moveTo(x + r, y); c.arcTo(x + w, y, x + w, y + h, r); c.arcTo(x + w, y + h, x, y + h, r); c.arcTo(x, y + h, x, y, r); c.arcTo(x, y, x + w, y, r); c.closePath(); }
  function drawAd(cv, o) {
    const [W, H] = FMT[o.fmt]; cv.width = W; cv.height = H; const c = cv.getContext('2d'), T = TPL[o.tpl], m = Math.min(W, H);
    const g = c.createLinearGradient(0, 0, W, H); T.bg.forEach((col, i) => g.addColorStop(i / (T.bg.length - 1), col)); c.fillStyle = g; c.fillRect(0, 0, W, H);
    c.globalAlpha = .12; c.fillStyle = o.tpl === 'light' ? '#E91E63' : '#fff'; c.beginPath(); c.arc(W * .92, H * .08, m * .34, 0, 7); c.fill(); c.beginPath(); c.arc(W * .04, H * .96, m * .28, 0, 7); c.fill(); c.globalAlpha = 1;
    const land = W > H * 1.3, p = Math.round(m * .055);
    const box = land ? { x: p, y: p, w: W * .46, h: H - 2 * p } : { x: p * 1.4, y: p * 1.2, w: W - p * 2.8, h: H * (o.fmt === 'st' ? .4 : .46) };
    const tx = land ? W * .5 + p : W / 2, tw = land ? W * .5 - 2 * p : W - 2 * p;
    // بطاقة المنتج
    c.save(); c.shadowColor = 'rgba(0,0,0,.28)'; c.shadowBlur = m * .04; c.shadowOffsetY = m * .015; c.fillStyle = '#fff'; rr(c, box.x, box.y, box.w, box.h, m * .04); c.fill(); c.restore();
    if (o.img) { const e = enhanced(o.img, box.w - p, box.h - p, o.enh); c.drawImage(e, box.x + p / 2, box.y + p / 2); }
    else { c.font = `${Math.min(box.w, box.h) * .6}px "Segoe UI Emoji","Apple Color Emoji","Noto Color Emoji",sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillStyle = '#000'; c.fillText(o.emoji || '🛍️', box.x + box.w / 2, box.y + box.h / 2 + m * .02); }
    // شارة السعر
    if (o.showPrice && o.price) {
      const r = m * .115, cx = box.x + box.w - r * .55, cy = box.y + r * .6;
      c.fillStyle = '#FFD60A'; c.beginPath(); c.arc(cx, cy, r, 0, 7); c.fill(); c.lineWidth = m * .008; c.strokeStyle = '#E91E63'; c.stroke();
      c.fillStyle = '#0B1F3B'; c.textAlign = 'center'; c.textBaseline = 'middle'; c.direction = 'ltr';
      c.font = `900 ${r * .62}px Cairo, Montserrat, sans-serif`; c.fillText(String(o.price), cx, cy - r * .12);
      c.font = `800 ${r * .3}px Cairo, Montserrat, sans-serif`; c.fillText('MAD', cx, cy + r * .42);
      if (o.old > o.price) { const s = Math.round((1 - o.price / o.old) * 100); c.fillStyle = '#E91E63'; rr(c, cx - r * .5, cy - r * 1.45, r, r * .5, r * .12); c.fill(); c.fillStyle = '#fff'; c.font = `900 ${r * .34}px Cairo, sans-serif`; c.fillText('-' + s + '%', cx, cy - r * 1.2); }
    }
    // نص
    let y = land ? H * .2 : box.y + box.h + p * 1.2;
    c.textAlign = 'center'; c.textBaseline = 'top';
    const fs = Math.round(m * (land ? .075 : .068)); c.font = `900 ${fs}px Cairo, Montserrat, "Segoe UI", sans-serif`; c.fillStyle = T.fg; c.direction = isAr(o.headline) ? 'rtl' : 'ltr';
    wrapText(c, o.headline, tw).slice(0, 3).forEach(l => { c.fillText(l, tx, y); y += fs * 1.2; });
    if (o.sub) { y += fs * .15; const f2 = Math.round(fs * .52); c.font = `700 ${f2}px Cairo, Montserrat, sans-serif`; c.fillStyle = T.sub; c.direction = isAr(o.sub) ? 'rtl' : 'ltr'; wrapText(c, o.sub, tw).slice(0, 2).forEach(l => { c.fillText(l, tx, y); y += f2 * 1.3; }); }
    // CTA
    if (o.cta) {
      const f3 = Math.round(fs * .55); c.font = `800 ${f3}px Cairo, Montserrat, sans-serif`; c.direction = isAr(o.cta) ? 'rtl' : 'ltr';
      const bw = Math.min(tw, c.measureText(o.cta).width + f3 * 2.4), bh = f3 * 2.1, bx = tx - bw / 2, by = y + fs * .35;
      const gg = c.createLinearGradient(bx, 0, bx + bw, 0); gg.addColorStop(0, '#FF3B30'); gg.addColorStop(.55, '#E91E63'); gg.addColorStop(1, '#FF9800');
      c.save(); c.shadowColor = 'rgba(0,0,0,.3)'; c.shadowBlur = 18; c.fillStyle = gg; rr(c, bx, by, bw, bh, bh / 2); c.fill(); c.restore();
      c.fillStyle = '#fff'; c.textBaseline = 'middle'; c.fillText(o.cta, tx, by + bh / 2 + 2); c.textBaseline = 'top';
    }
    // الشعار
    c.direction = 'ltr'; c.textAlign = land ? 'left' : 'center'; c.textBaseline = 'alphabetic';
    const lx = land ? tx - tw / 2 : W / 2, ly = H - p * .9;
    c.font = `900 ${Math.round(m * .06)}px Montserrat, Cairo, sans-serif`; const lg = c.createLinearGradient(lx - 120, 0, lx + 160, 0); lg.addColorStop(0, o.tpl === 'fire' ? '#fff' : '#FF3B30'); lg.addColorStop(1, o.tpl === 'fire' ? '#fff3d6' : '#FF9800'); c.fillStyle = o.tpl === 'light' ? lg : (o.tpl === 'navy' ? lg : '#fff'); c.fillText('VMC ▶', lx, ly);
    c.font = `700 ${Math.round(m * .022)}px Montserrat, sans-serif`; c.fillStyle = T.fg; c.globalAlpha = .8; c.fillText('LIVE SHOPPING NETWORK', lx, ly + m * .032); c.globalAlpha = 1;
  }
  VIEWS.studio = function () {
    const p = DB.products;
    $('#main').innerHTML = `<h1>🎨 استوديو الإعلانات</h1>
      <div class="panel"><p class="note" style="margin:0 0 12px">يصمّم إعلانات جاهزة بهوية VMC (مربع، ستوري، أفقي) ويحسّن جودة صور منتجاتك (تباين، ألوان، حدّة) داخل المتصفح دون إرسال صورك لأي جهة. لتوليد صور بالذكاء الاصطناعي من الصفر (مثل خلفيات استوديو) يلزم ربط مزوّد صور خارجي.</p>
      <div class="studio"><div>
        <div class="field"><label>المنتج</label><select id="sP"><option value="">— بدون —</option>${p.map(x => `<option value="${x.id}">${esc(x.name.ar)}</option>`).join('')}</select></div>
        <div class="field"><label>صورة المنتج (اختياري)</label><input type="file" id="sF" accept="image/*"></div>
        <div class="field"><label>تحسين الجودة: <b id="eV">60</b>%</label><input type="range" id="sE" min="0" max="100" value="60"></div>
        <div class="field"><label>المقاس</label><select id="sFmt">${Object.entries(FMT).map(([k, v]) => `<option value="${k}">${v[2]}</option>`).join('')}</select></div>
        <div class="field"><label>القالب</label><select id="sT"><option value="navy">كحلي + وردي</option><option value="light">أبيض فاتح</option><option value="fire">أحمر + برتقالي</option></select></div>
        <div class="field"><label>العنوان</label><input id="sH"></div>
        <div class="field"><label>سطر فرعي</label><input id="sS" value="الدفع عند الاستلام · توصيل لكل المغرب"></div>
        <div class="field"><label>زر الدعوة</label><input id="sC" value="اطلب الآن"></div>
        <div class="field"><label><input type="checkbox" id="sPr" checked> إظهار شارة السعر</label></div>
        <div class="row-btn"><button class="btn primary" id="dlPng">⬇ PNG</button><button class="btn dark" id="dlJpg">⬇ JPG</button></div>
        <div class="row-btn"><button class="mini-btn ok" id="savePhoto">✓ حفظ الصورة المحسّنة كصورة للمنتج</button></div>
      </div><div><canvas id="cv"></canvas></div></div></div>`;
    const st = () => { const x = p.find(y => y.id === +$('#sP').value); return { x, o: { fmt: $('#sFmt').value, tpl: $('#sT').value, headline: $('#sH').value, sub: $('#sS').value, cta: $('#sC').value, showPrice: $('#sPr').checked, enh: +$('#sE').value, price: x && x.price, old: x && x.old, emoji: x && x.emoji, img: SS.img } }; };
    const draw = async () => { try { await document.fonts.load('900 40px Cairo'); await document.fonts.load('900 40px Montserrat'); } catch (e) {} drawAd($('#cv'), st().o); };
    $('#sP').onchange = () => { const x = p.find(y => y.id === +$('#sP').value); if (x) { $('#sH').value = x.name.ar; SS.img = null; if (x.image) { const im = new Image(); im.crossOrigin = 'anonymous'; im.onload = () => { SS.img = im; draw(); }; im.src = x.image; } } draw(); };
    $('#sF').onchange = async e => { const f = e.target.files[0]; if (!f) return; const u = await fileToDataURL(f, 1600, 'image/png'); const im = new Image(); im.onload = () => { SS.img = im; draw(); }; im.src = u; };
    ['sE', 'sFmt', 'sT', 'sH', 'sS', 'sC', 'sPr'].forEach(id => $('#' + id).addEventListener('input', () => { if (id === 'sE') $('#eV').textContent = $('#sE').value; draw(); }));
    const dl = (type, ext) => { const a = document.createElement('a'); a.href = $('#cv').toDataURL(type, .92); a.download = 'vmc-ad-' + $('#sFmt').value + '.' + ext; a.click(); };
    $('#dlPng').onclick = () => dl('image/png', 'png'); $('#dlJpg').onclick = () => dl('image/jpeg', 'jpg');
    $('#savePhoto').onclick = async () => {
      const { x } = st(); if (!x || !SS.img) return toast('اختر منتجاً وارفع صورة له أولاً');
      try {
        const c = document.createElement('canvas'); c.width = c.height = 900; const k = c.getContext('2d'); k.fillStyle = '#fff'; k.fillRect(0, 0, 900, 900);
        k.drawImage(enhanced(SS.img, 840, 840, +$('#sE').value), 30, 30);
        x.image = await storeImage(c.toDataURL('image/jpeg', .88)); await saveStore(['products']); toast('✓ حُفظت صورة المنتج');
      } catch (e) { fail(e); }
    };
    draw();
  };

  /* ================= التسويق والسيو ================= */
  const PX = [
    ['meta', 'Meta Pixel (Facebook + Instagram)', '1234567890123456'], ['tiktok', 'TikTok Pixel', 'C1ABCDEFGHIJ...'], ['snapchat', 'Snapchat Pixel', 'xxxxxxxx-xxxx-…'],
    ['pinterest', 'Pinterest Tag', '2612345678901'], ['ga4', 'Google Analytics 4', 'G-XXXXXXXXXX'], ['gtm', 'Google Tag Manager', 'GTM-XXXXXXX'],
    ['gadsId', 'Google Ads ID', 'AW-123456789'], ['gadsLabel', 'Google Ads – Purchase label', 'AbC-dEfGhIj'], ['twitter', 'X (Twitter) Pixel', 'o1abc'], ['twitterPurchase', 'X – Purchase event ID', 'tw-o1abc-o2xyz'],
    ['verifyMeta', 'Meta domain verification', 'كود التحقق فقط'], ['verifyGoogle', 'Google Search Console verification', 'كود التحقق فقط']
  ];
  VIEWS.marketing = function () {
    const s = DB.seo, px = DB.pixels;
    const sv = (k, l) => (s[k] && s[k][l]) || '';
    $('#main').innerHTML = `<h1>📈 التسويق والسيو</h1>${warnLocal()}
      <div class="panel"><h2>🎯 بيكسلات التتبع</h2>
        <p class="note">تُحمَّل بعد موافقة الزائر على الكوكيز، وترسل أحداث: ViewContent · AddToCart · InitiateCheckout · Purchase (بالقيمة والعملة MAD).</p><br>
        <div class="form">${PX.map(([k, n, ph]) => `<div class="field"><label>${n}</label><input data-px="${k}" value="${esc(px[k] || '')}" placeholder="${esc(ph)}" dir="ltr"></div>`).join('')}</div>
        <div class="row-btn"><button class="btn primary" id="savePx">حفظ البيكسلات</button><button class="btn dark" id="copyPx">نسخ كود الإعداد (للاستضافة الثابتة)</button></div>
        <p class="note">للاستضافة الثابتة بدون خادم: الصق الكود المنسوخ مكان VMC_DEFAULT_PIXELS في assets/data.js.</p></div>
      <div class="panel"><h2>🔎 إعدادات السيو</h2><div class="form">
        <div class="field full"><label>عنوان موقعك النهائي (https://…)</label><input id="seoSite" value="${esc(s.siteUrl || '')}" dir="ltr"></div>
        ${['ar', 'fr', 'en'].map(l => `<div class="field full"><label>Title ${l.toUpperCase()} (≈60 حرفاً)</label><input data-seo="title:${l}" value="${esc(sv('title', l))}"></div>
          <div class="field full"><label>Description ${l.toUpperCase()} (≈155 حرفاً)</label><textarea data-seo="description:${l}" rows="2">${esc(sv('description', l))}</textarea></div>
          <div class="field full"><label>Keywords ${l.toUpperCase()}</label><input data-seo="keywords:${l}" value="${esc(sv('keywords', l))}"></div>`).join('')}
      </div><div class="row-btn"><button class="btn primary" id="saveSeo">حفظ وإعادة توليد sitemap وصفحات المنتجات</button></div>
      <h3>ما يتم توليده تلقائياً</h3><p class="note">وسوم ميتا وOpen Graph وTwitter Card لكل لغة · hreflang · canonical · JSON-LD (Organization, WebSite, OnlineStore, ItemList, Product, BreadcrumbList) · صفحات منتجات ثابتة بثلاث لغات في /p/ · sitemap.xml وrobots.txt. بعد النشر: أرسل sitemap.xml إلى Google Search Console وBing Webmaster Tools.</p></div>
      <div class="panel"><h2>🔗 روابط الحملات (UTM)</h2><div class="form">
        <div class="field"><label>المنصة</label><select id="uS"><option>facebook</option><option>instagram</option><option>tiktok</option><option>snapchat</option><option>google</option><option>pinterest</option><option>whatsapp</option></select></div>
        <div class="field"><label>اسم الحملة</label><input id="uC" value="launch"></div>
        <div class="field"><label>المنتج</label><select id="uP"><option value="">الصفحة الرئيسية</option>${DB.products.map(x => `<option value="${x.id}">${esc(x.name.ar)}</option>`).join('')}</select></div></div>
        <div class="row-btn"><button class="btn dark" id="uGo">توليد الرابط</button></div><pre id="uOut" style="display:none"></pre></div>`;
    $('#savePx').onclick = () => { $$('[data-px]').forEach(i => DB.pixels[i.dataset.px] = i.value.trim()); saveStore(['pixels']).catch(fail); };
    $('#copyPx').onclick = () => { $$('[data-px]').forEach(i => DB.pixels[i.dataset.px] = i.value.trim()); copy('const VMC_DEFAULT_PIXELS = ' + JSON.stringify(DB.pixels, null, 2) + ';'); };
    $('#saveSeo').onclick = () => {
      DB.seo.siteUrl = $('#seoSite').value.trim().replace(/\/+$/, '');
      $$('[data-seo]').forEach(i => { const [k, l] = i.dataset.seo.split(':'); DB.seo[k] = DB.seo[k] || {}; DB.seo[k][l] = i.value.trim(); });
      saveStore(['seo']).then(r => { if (r && r.seo) toast('✓ تم توليد ' + r.seo.pages + ' صفحة منتج + sitemap'); }).catch(fail);
    };
    $('#uGo').onclick = () => {
      const base = (DB.seo.siteUrl || VMC_CONFIG.siteUrl).replace(/\/+$/, ''), pid = $('#uP').value;
      const u = new URL(base + '/'); if (pid) u.searchParams.set('product', pid);
      u.searchParams.set('utm_source', $('#uS').value); u.searchParams.set('utm_medium', 'paid_social'); u.searchParams.set('utm_campaign', $('#uC').value.trim() || 'campaign');
      const o = $('#uOut'); o.style.display = 'block'; o.textContent = u.toString(); copy(u.toString());
    };
  };


  /* ================= الآراء والمشتركون ================= */
  VIEWS.reviews = async function () {
    if (!API) { $('#main').innerHTML = '<h1>⭐ الآراء والمشتركون</h1><div class="warn">هذه الصفحة تعمل مع الخادم فقط (node server.js).</div>'; return; }
    let rv = [], subs = [];
    let leads = []; try { rv = await req('api/admin/reviews'); subs = await req('api/admin/subscribers'); leads = await req('api/admin/leads'); } catch (e) { return fail(e); }
    const pn = id => ((DB.products.find(x => x.id === id) || {}).name || {}).ar || id;
    $('#main').innerHTML = `<h1>⭐ الآراء والمشتركون</h1>
      <div class="panel"><h2>🤖 طلبات اتصال من الدردشة (${leads.filter(x => !x.done).length} جديد)</h2>${leads.length ? `<div class="tw"><table><tr><th>الهاتف</th><th>الموضوع</th><th>التاريخ</th><th></th></tr>${leads.map(l => `<tr><td dir="ltr"><b>${esc(l.phone)}</b><br>${esc(l.name || '')}</td><td>${esc(l.topic)}</td><td>${new Date(l.date).toLocaleString('fr-FR')}</td><td><a class="mini-btn ok" href="https://wa.me/${esc(String(l.phone).replace(/^0/, '212').replace(/\D/g, ''))}" target="_blank" rel="noopener">💬</a><button class="mini-btn ${l.done ? '' : 'red'}" data-ld2="${l.id}" data-dn="${l.done ? 0 : 1}">${l.done ? 'إعادة فتح' : 'تم'}</button></td></tr>`).join('')}</table></div>` : '<p class="note">لا توجد طلبات اتصال.</p>'}</div>
      <div class="panel"><h2>آراء الزبائن (${rv.length})</h2><p class="note">لا يظهر أي رأي في المتجر قبل موافقتك. لا تنشر إلا الآراء الحقيقية.</p>
        ${rv.length ? `<div class="tw"><table><tr><th>المنتج</th><th>التقييم</th><th>الرأي</th><th>الحالة</th><th></th></tr>${rv.map(r => `<tr><td>${esc(pn(r.productId))}</td><td>${'★'.repeat(r.rating)}${'☆'.repeat(5 - r.rating)}</td><td><b>${esc(r.name)}</b><br>${esc(r.comment)}</td>
          <td><span class="pill ${r.approved ? 'delivered' : 'new'}">${r.approved ? 'منشور' : 'بانتظار المراجعة'}</span></td>
          <td><button class="mini-btn ok" data-rv="${r.id}" data-ap="${r.approved ? 0 : 1}">${r.approved ? 'إخفاء' : 'نشر'}</button><button class="mini-btn red" data-rd="${r.id}">حذف</button></td></tr>`).join('')}</table></div>` : '<p class="note">لا توجد آراء بعد.</p>'}</div>
      <div class="panel"><h2>المشتركون في النشرة (${subs.length})</h2><button class="mini-btn" id="subCsv">⬇ CSV</button><br>
        ${subs.length ? `<div class="tw"><table><tr><th>الوسيلة</th><th>النوع</th><th>التاريخ</th></tr>${subs.slice(0, 100).map(x => `<tr><td dir="ltr">${esc(x.contact)}</td><td>${esc(x.type)}</td><td>${new Date(x.date).toLocaleDateString('fr-FR')}</td></tr>`).join('')}</table></div>` : '<p class="note">لا يوجد مشتركون بعد.</p>'}</div>`;
    $$('[data-ld2]').forEach(b => b.onclick = () => req('api/admin/leads/' + b.dataset.ld2, { method: 'PATCH', body: JSON.stringify({ done: b.dataset.dn === '1' }) }).then(VIEWS.reviews).catch(fail));
    $$('[data-rv]').forEach(b => b.onclick = () => req('api/admin/reviews/' + b.dataset.rv, { method: 'PATCH', body: JSON.stringify({ approved: b.dataset.ap === '1' }) }).then(VIEWS.reviews).catch(fail));
    $$('[data-rd]').forEach(b => b.onclick = () => confirm('حذف الرأي؟') && req('api/admin/reviews/' + b.dataset.rd, { method: 'DELETE' }).then(VIEWS.reviews).catch(fail));
    const sc = $('#subCsv'); if (sc) sc.onclick = () => { const t = '﻿' + 'contact,type,date\n' + subs.map(x => [x.contact, x.type, x.date].map(c => '"' + String(c).replace(/"/g, '""') + '"').join(',')).join('\n'); const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([t], { type: 'text/csv;charset=utf-8' })); a.download = 'vmc-subscribers.csv'; a.click(); };
  };

  /* ================= إقلاع ================= */
  detect().then(() => { $('#loginNote').innerHTML = API ? 'متصل بالخادم ✓' : 'وضع تجريبي بدون خادم (كلمة السر في assets/data.js)'; show(); });
})();
