/* VMC – ويدجت الدردشة (يعتمد على /api/chat) */
(function () {
  'use strict';
  const HTTP = /^https?:$/.test(location.protocol);
  const $ = (s, r = document) => r.querySelector(s);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const lang = () => (VMC_I18N[document.documentElement.lang] ? document.documentElement.lang : 'ar');
  const T = k => (VMC_I18N[lang()] || VMC_I18N.ar)[k];
  const KEY = 'vmc_chat_v1';
  let msgs = []; try { msgs = JSON.parse(sessionStorage.getItem(KEY) || '[]'); } catch (e) {}
  let busy = false, built = false;

  const fab = document.createElement('button');
  fab.id = 'chatFab'; fab.setAttribute('aria-label', 'chat'); fab.innerHTML = '💬<span>AI</span>';
  document.body.appendChild(fab);
  const box = document.createElement('section');
  box.id = 'chatBox'; box.setAttribute('role', 'dialog'); box.hidden = true;
  box.innerHTML = `<header><div class="av">V</div><div><b id="chT"></b><small id="chS"></small></div><button id="chX" aria-label="close">✕</button></header>
    <div id="chLog" aria-live="polite"></div><div id="chChips"></div>
    <form id="chForm"><input id="chIn" maxlength="500" autocomplete="off"><button aria-label="send">➤</button></form><div class="disc" id="chD"></div>`;
  document.body.appendChild(box);

  function save() { try { sessionStorage.setItem(KEY, JSON.stringify(msgs.slice(-20))); } catch (e) {} }
  function text() { $('#chT').textContent = T('chat_title'); $('#chS').textContent = T('chat_sub'); $('#chIn').placeholder = T('chat_ph'); $('#chD').textContent = T('chat_ai'); }
  function chips() {
    $('#chChips').innerHTML = msgs.length > 1 ? '' : T('chat_chips').map(c => `<button type="button">${esc(c)}</button>`).join('');
    $('#chChips').querySelectorAll('button').forEach(b => b.onclick = () => send(b.textContent));
  }
  function bubble(role, content, extra) {
    const d = document.createElement('div'); d.className = 'm ' + role;
    d.innerHTML = esc(content).replace(/\n/g, '<br>').replace(/(https?:\/\/[^\s<]+)/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
    if (extra && extra.products && extra.products.length) {
      const w = document.createElement('div'); w.className = 'pc';
      extra.products.forEach(p => {
        const c = document.createElement('div'); c.className = 'pcard';
        c.innerHTML = `<div class="pi">${p.image ? `<img src="${esc(p.image)}" alt="">` : esc(p.emoji || '🛍️')}</div><div class="pt"><b>${esc(p.name)}</b><span>${esc(p.price)} MAD${p.old > p.price ? ` <s>${esc(p.old)}</s>` : ''}</span></div><button type="button">${esc(T('chat_add'))}</button>`;
        c.querySelector('button').onclick = () => { if (window.VMCApp) VMCApp.addToCart(p.id); };
        c.querySelector('.pi').onclick = c.querySelector('b').onclick = () => { if (window.VMCApp) { box.hidden = true; VMCApp.viewProduct(p.id); } };
        w.appendChild(c);
      });
      d.appendChild(w);
    }
    if (extra && extra.whatsapp) { const a = document.createElement('a'); a.className = 'wabtn'; a.href = extra.whatsapp; a.target = '_blank'; a.rel = 'noopener'; a.textContent = '💬 ' + T('chat_wa'); d.appendChild(a); }
    $('#chLog').appendChild(d); $('#chLog').scrollTop = 1e6; return d;
  }
  function renderAll() {
    $('#chLog').innerHTML = ''; bubble('bot', T('chat_hello'));
    msgs.forEach(m => bubble(m.role === 'user' ? 'me' : 'bot', m.content, m.extra));
    chips();
  }
  async function send(t) {
    t = String(t || '').trim(); if (!t || busy) return;
    busy = true; $('#chIn').value = ''; msgs.push({ role: 'user', content: t }); bubble('me', t); chips(); save();
    const typing = bubble('bot', '…'); typing.classList.add('typing');
    let out = null;
    if (HTTP) {
      try {
        const r = await fetch('api/chat', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ lang: lang(), messages: msgs.map(m => ({ role: m.role, content: m.content })) }) });
        if (r.ok) out = await r.json();
      } catch (e) {}
    }
    typing.remove();
    if (out && out.reply) { msgs.push({ role: 'assistant', content: out.reply, extra: { products: out.products, whatsapp: out.whatsapp } }); bubble('bot', out.reply, { products: out.products, whatsapp: out.whatsapp }); }
    else { const w = 'https://wa.me/' + VMC_CONFIG.whatsapp; bubble('bot', T('chat_err'), { whatsapp: w }); msgs.pop(); }
    save(); busy = false; $('#chIn').focus();
  }
  function open(o) { box.hidden = !o; fab.classList.toggle('on', o); if (o) { if (!built) { built = true; } text(); renderAll(); setTimeout(() => $('#chIn').focus(), 50); } }
  fab.onclick = () => open(box.hidden);
  $('#chX').onclick = () => open(false);
  $('#chForm').addEventListener('submit', e => { e.preventDefault(); send($('#chIn').value); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !box.hidden) open(false); });
  new MutationObserver(() => { if (!box.hidden) { text(); renderAll(); } }).observe(document.documentElement, { attributes: true, attributeFilter: ['lang'] });
})();
