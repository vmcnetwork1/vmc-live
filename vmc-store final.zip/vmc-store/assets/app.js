/* VMC – Vision Media Commerce | منطق المتجر */
(function () {
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const store = {
    get(k, d) { try { const v = JSON.parse(localStorage.getItem(k)); return v == null ? d : v; } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

  const HTTP = /^https?:$/.test(location.protocol);
  const qp = new URLSearchParams(location.search);
  let lang = store.get('vmc_lang', 'ar');
  if (qp.get('lang') && VMC_I18N[qp.get('lang')]) lang = qp.get('lang');
  if (!VMC_I18N[lang]) lang = 'ar';
  let products = store.get('vmc_products', null) || VMC_DEFAULT_PRODUCTS;
  let lives = store.get('vmc_lives', null) || VMC_DEFAULT_LIVES;
  let seo = VMC_DEFAULT_SEO;
  let pixels = VMC_DEFAULT_PIXELS;
  const site = () => String((seo && seo.siteUrl) || VMC_CONFIG.siteUrl).replace(/\/+$/, '');
  const pxItems = (id, qty) => { const p = byId(id); return p ? [{ id: p.id, name: L(p.name), price: p.price, qty: qty || 1 }] : []; };
  const track = (ev, d) => { try { window.VMCPixels && VMCPixels.track(ev, d); } catch (e) {} };

  async function loadRemote() {
    if (!HTTP) return;
    try {
      const r = await fetch('api/store'); if (!r.ok) return;
      const s = await r.json();
      if (Array.isArray(s.products) && s.products.length) products = s.products;
      if (Array.isArray(s.lives)) lives = s.lives;
      if (s.pixels) pixels = s.pixels;
      if (s.seo) seo = s.seo;
      if (s.reviews) reviews = s.reviews;
    } catch (e) { /* وضع بدون خادم: نستعمل البيانات المحلية */ }
  }

  /* ---------- SEO ديناميكي ---------- */
  function setMeta(sel, attr, val) { const el = $(sel); if (el) el.setAttribute(attr, val); }
  function applySEO() {
    const t = (seo.title && seo.title[lang]) || VMC_DEFAULT_SEO.title[lang];
    const d = (seo.description && seo.description[lang]) || VMC_DEFAULT_SEO.description[lang];
    const k = (seo.keywords && seo.keywords[lang]) || '';
    const base = site(), url = base + '/?lang=' + lang;
    document.title = t;
    setMeta('meta[name=description]', 'content', d);
    setMeta('meta[name=keywords]', 'content', k);
    setMeta('meta[property="og:title"]', 'content', t);
    setMeta('meta[property="og:description"]', 'content', d);
    setMeta('meta[property="og:url"]', 'content', url);
    setMeta('meta[property="og:locale"]', 'content', { ar: 'ar_MA', fr: 'fr_MA', en: 'en_US' }[lang]);
    setMeta('meta[name="twitter:title"]', 'content', t);
    setMeta('meta[name="twitter:description"]', 'content', d);
    setMeta('link[rel=canonical]', 'href', url);
    const ld = $('#ld-products');
    if (ld) ld.textContent = JSON.stringify({
      '@context': 'https://schema.org', '@type': 'ItemList', name: t,
      itemListElement: products.slice(0, 50).map((p, i) => ({
        '@type': 'ListItem', position: i + 1, url: base + '/p/' + lang + '/' + p.id + '.html',
        item: {
          '@type': 'Product', name: L(p.name), description: L(p.desc), sku: 'VMC-' + p.id,
          image: /^https?:/.test(p.image || '') ? p.image : base + '/' + (p.image || 'assets/img/og-image.jpg'),
          brand: { '@type': 'Brand', name: 'VMC' },
          offers: { '@type': 'Offer', priceCurrency: VMC_CONFIG.currencyCode, price: String(p.price), availability: 'https://schema.org/InStock', url: base + '/p/' + lang + '/' + p.id + '.html' }
        }
      }))
    }).replace(/</g, '\\u003c');
  }
  let cart = store.get('vmc_cart', []);          // [{id, qty}]
  let state = { cat: 'all', q: '', sort: 'def' };
  let wish = store.get('vmc_wish', []);
  let reviews = {};
  const saveWish = () => store.set('vmc_wish', wish);

  const T = k => VMC_I18N[lang][k] || k;
  const L = o => (o && (o[lang] || o.fr || o.en || o.ar)) || '';
  const money = n => n.toLocaleString(lang === 'fr' ? 'fr-FR' : 'en-US') + ' ' + VMC_CONFIG.currency[lang];
  const byId = id => products.find(p => p.id === id);

  /* ---------- Language ---------- */
  function renderSlogan() {
    const parts = T('slogan').split(/[.。]/).map(s => s.trim()).filter(Boolean);
    $('#slogan').innerHTML = parts.map(s => `<span>${esc(s)}.</span>`).join('');
  }
  function renderTiles() {
    $('#catTiles').innerHTML = VMC_CATEGORIES.map(c => {
      const n = c.id === 'deals' ? products.filter(p => p.old > p.price).length : products.filter(p => p.cat === c.id).length;
      return `<button class="tile" data-tile="${c.id}"><span class="ti" aria-hidden="true">${c.icon}</span><span><b>${esc(L(c.name))}</b><small>${n} ${T('items')}</small></span></button>`;
    }).join('');
  }
  function applyLang(first) {
    const d = VMC_I18N[lang];
    document.documentElement.lang = lang;
    document.documentElement.dir = d.dir;
    $$('[data-i]').forEach(el => el.textContent = T(el.dataset.i));
    $$('[data-ph]').forEach(el => el.placeholder = T(el.dataset.ph));
    $('#brandSub').textContent = d.brandSub;
    $('#topbar').innerHTML = '🚚 <b>' + T('f4_t') + '</b> · ' + T('f3_t') + ' · ' + d.slogan;
    $('#rights').textContent = '© ' + new Date().getFullYear() + ' VMC – Vision Media Commerce. ' + T('rights');
    $('#tagline').textContent = T('tagline');
    $$('#lang button').forEach(b => b.classList.toggle('on', b.dataset.l === lang));
    $('#sort').innerHTML = [['def', 'sort_def'], ['low', 'sort_low'], ['high', 'sort_high']]
      .map(([v, k]) => `<option value="${v}" ${state.sort === v ? 'selected' : ''}>${T(k)}</option>`).join('');
    renderSlogan(); renderCart();
    $('#toTop').setAttribute('aria-label', T('to_top'));
    const heavy = () => { renderTiles(); renderCats(); renderProducts(); renderDeals(); renderLives(); renderWishCount(); renderFootSocial(); applySEO(); };
    if (first) { clearTimeout(heavy.t); const run = () => { heavy.pending = false; heavy(); }; heavy.pending = true; ('requestIdleCallback' in window) ? requestIdleCallback(run, { timeout: 350 }) : setTimeout(run, 40); }
    else heavy();
  }

  /* ---------- Shop ---------- */
  function renderCats() {
    const all = [{ id: 'all', icon: '✨', name: { ar: T('all'), fr: T('all'), en: T('all') } }, { id: 'wish', icon: '♡', name: { ar: T('wish'), fr: T('wish'), en: T('wish') } }, ...VMC_CATEGORIES];
    $('#cats').innerHTML = all.map(c =>
      `<button class="chip ${state.cat === c.id ? 'on' : ''}" data-c="${c.id}">${c.icon} ${esc(L(c.name))}</button>`).join('');
  }
  function renderProducts() {
    let list = products.filter(p => {
      const inCat = state.cat === 'all' || (state.cat === 'wish' && wish.includes(p.id)) || p.cat === state.cat || (state.cat === 'deals' && p.old > p.price);
      const hay = (L(p.name) + ' ' + L(p.desc)).toLowerCase();
      return inCat && (!state.q || hay.includes(state.q.toLowerCase()));
    });
    if (state.sort === 'low') list = [...list].sort((a, b) => a.price - b.price);
    if (state.sort === 'high') list = [...list].sort((a, b) => b.price - a.price);
    const bgs = ['#FFE9EF', '#FFF1DD', '#EDE7FF', '#E6F1FF', '#E6F8EE', '#FFEAE5'];
    $('#grid').innerHTML = list.length ? list.map(cardHTML).join('') : `<div class="empty">${T(state.cat === 'wish' ? 'wish_empty' : 'no_results')}</div>`;
  }
  const BGS = ['#FFE9EF', '#FFF1DD', '#EDE7FF', '#E6F1FF', '#E6F8EE', '#FFEAE5'];
  const rating = id => { const r = reviews[id] || []; return r.length ? { avg: r.reduce((s, x) => s + x.rating, 0) / r.length, n: r.length } : null; };
  const starsHTML = id => { const r = rating(id); if (!r) return ''; const f = Math.round(r.avg); return `<div class="stars">${'★'.repeat(f)}${'☆'.repeat(5 - f)}<small>${r.avg.toFixed(1)} (${r.n})</small></div>`; };
  function cardHTML(p) {
    const sale = p.old > p.price ? Math.round((1 - p.price / p.old) * 100) : 0;
    const vis = p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" loading="lazy">` : p.emoji || '🛍️';
    return `<article class="card">
      <div class="vis" data-view="${p.id}" style="background:${BGS[p.id % BGS.length]};cursor:pointer">${vis}
        <button class="heart ${wish.includes(p.id) ? 'on' : ''}" data-wish="${p.id}" aria-label="${esc(T('wish'))}" aria-pressed="${wish.includes(p.id)}">${wish.includes(p.id) ? '♥' : '♡'}</button>
        ${sale ? `<span class="tag sale">-${sale}%</span>` : ''}
        ${p.live ? `<span class="tag live">${T('in_live')}</span>` : ''}
      </div>
      <div class="body"><h3 data-view="${p.id}" style="cursor:pointer">${esc(L(p.name))}</h3>${starsHTML(p.id)}<p>${esc(L(p.desc))}</p>
        <div class="price"><b>${money(p.price)}</b>${p.old > p.price ? `<s>${money(p.old)}</s>` : ''}</div>
        <button class="add" data-add="${p.id}">🛒 ${T('add')}</button>
      </div></article>`;
  }

  /* ---------- عروض اليوم ---------- */
  function renderDeals() {
    const d = products.filter(p => p.old > p.price).sort((a, b) => (b.old - b.price) / b.old - (a.old - a.price) / a.old).slice(0, 4);
    $('#deals').style.display = d.length ? '' : 'none';
    $('#dealGrid').innerHTML = d.map(cardHTML).join('');
  }
  function tick() {
    const n = new Date(), e = new Date(n); e.setHours(23, 59, 59, 999);
    const s = Math.max(0, Math.floor((e - n) / 1000)), z = v => String(v).padStart(2, '0');
    const el = $('#dealTimer'); if (el) el.textContent = z(Math.floor(s / 3600)) + ':' + z(Math.floor(s % 3600 / 60)) + ':' + z(s % 60);
  }
  setInterval(tick, 1000); tick();

  /* ---------- المفضلة ---------- */
  function renderWishCount() { $('#wishCount').textContent = wish.length; }
  function toggleWish(id) {
    wish = wish.includes(id) ? wish.filter(x => x !== id) : [...wish, id]; saveWish();
    renderWishCount(); renderProducts(); renderDeals();
  }
  function renderFootSocial() {
    const s = VMC_CONFIG.social;
    $('#footSocial').innerHTML = Object.keys(s).map(k => `<a href="${esc(s[k])}" target="_blank" rel="noopener" style="display:block;margin-bottom:6px">${PLAT[k]}</a>`).join('');
  }

  /* ---------- Live ---------- */
  const PICON = {
    youtube: '<path d="M23.5 6.2a3 3 0 0 0-2.1-2.1C19.5 3.6 12 3.6 12 3.6s-7.5 0-9.4.5A3 3 0 0 0 .5 6.2C0 8.1 0 12 0 12s0 3.9.5 5.8a3 3 0 0 0 2.1 2.1c1.9.5 9.4.5 9.4.5s7.5 0 9.4-.5a3 3 0 0 0 2.1-2.1c.5-1.9.5-5.8.5-5.8s0-3.9-.5-5.8zM9.6 15.6V8.4l6.2 3.6-6.2 3.6z"/>',
    facebook: '<path d="M24 12a12 12 0 1 0-13.9 11.9v-8.4H7.1V12h3V9.4c0-3 1.8-4.7 4.5-4.7 1.3 0 2.7.2 2.7.2v3h-1.5c-1.5 0-2 .9-2 1.9V12h3.4l-.5 3.5h-2.9v8.4A12 12 0 0 0 24 12z"/>',
    tiktok: '<path d="M19.6 6.7a5.4 5.4 0 0 1-3.3-1.1 5.4 5.4 0 0 1-2-3.6h-3.5v13.3a2.6 2.6 0 1 1-1.8-2.5V9.2a6.1 6.1 0 1 0 5.3 6V9a8.9 8.9 0 0 0 5.3 1.7V6.7z"/>',
    instagram: '<path d="M12 2.2c3.2 0 3.6 0 4.8.1 3.3.1 4.8 1.7 4.9 4.9.1 1.3.1 1.6.1 4.8s0 3.6-.1 4.8c-.1 3.2-1.7 4.8-4.9 4.9-1.3.1-1.6.1-4.8.1s-3.6 0-4.8-.1c-3.3-.1-4.8-1.7-4.9-4.9C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.8C2.4 3.9 4 2.4 7.2 2.3 8.4 2.2 8.8 2.2 12 2.2zM12 0C8.7 0 8.3 0 7.1.1 2.7.3.3 2.7.1 7.1 0 8.3 0 8.7 0 12s0 3.7.1 4.9c.2 4.4 2.6 6.8 7 7C8.3 24 8.7 24 12 24s3.7 0 4.9-.1c4.4-.2 6.8-2.6 7-7 .1-1.2.1-1.6.1-4.9s0-3.7-.1-4.9c-.2-4.4-2.6-6.8-7-7C15.7 0 15.3 0 12 0zm0 5.8a6.2 6.2 0 1 0 0 12.4 6.2 6.2 0 0 0 0-12.4zM12 16a4 4 0 1 1 0-8 4 4 0 0 1 0 8zm6.4-11.8a1.4 1.4 0 1 0 0 2.9 1.4 1.4 0 0 0 0-2.9z"/>'
  };
  const PNAME = { youtube: 'YouTube', facebook: 'Facebook', tiktok: 'TikTok', instagram: 'Instagram' };
  const PLAT = {};
  Object.keys(PNAME).forEach(k => { PLAT[k] = `<span class="pi pi-${k}" aria-hidden="true"><svg viewBox="0 0 24 24" width="14" height="14" fill="#fff">${PICON[k]}</svg></span>${PNAME[k]}`; });
  function renderGuide() {
    const fmt = new Intl.DateTimeFormat(lang === 'ar' ? 'ar-MA-u-nu-latn' : lang, { weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' });
    const items = lives.filter(l => l.status === 'live' || (l.at && new Date(l.at) > new Date(Date.now() - 2 * 3600e3)))
      .sort((a, b) => (a.status === 'live' ? -1 : 0) - (b.status === 'live' ? -1 : 0) || new Date(a.at || 0) - new Date(b.at || 0));
    $('#guideList').innerHTML = items.length ? items.map(l => `<div class="slot">
      <span class="t">${l.status === 'live' ? '<span class="badge-live">LIVE</span>' : esc(fmt.format(new Date(l.at)))}</span>
      <span class="n">${esc(L(l.title))}</span><span>${PLAT[l.platform] || ''}</span>
      <button class="btn primary" style="padding:8px 16px;font-size:13px" data-watch="${l.id}">▶ ${T('watch')}</button></div>`).join('') : `<p style="color:#c3cce0">${T('guide_empty')}</p>`;
  }
  function renderLives() {
    renderGuide();
    $('#livePill').hidden = !lives.some(l => l.status === 'live');
    $('#lives').innerHTML = lives.map(l => {
      const chips = (l.products || []).map(byId).filter(Boolean)
        .map(p => `<span data-add="${p.id}">${p.emoji || '🛍️'} ${esc(L(p.name))} · ${money(p.price)}</span>`).join('');
      return `<div class="live-card">
        <div class="plat"><span class="p">${PLAT[l.platform] || esc(l.platform)}</span>
          <span class="status ${l.status === 'live' ? 'live' : ''}">${l.status === 'live' ? '● ' + T('live_now') : T('live_soon')}</span></div>
        <h3>${esc(L(l.title))}</h3>
        ${chips ? `<div><small>${T('featured')}</small><div class="mini" style="margin-top:6px">${chips}</div></div>` : ''}
        <button class="btn primary" data-watch="${l.id}">▶ ${T('watch')}</button></div>`;
    }).join('');
    const s = VMC_CONFIG.social;
    $('#socials').innerHTML = Object.keys(s).map(k =>
      `<a href="${esc(s[k])}" target="_blank" rel="noopener">${PLAT[k]}</a>`).join('');
  }
  function ytEmbed(url) {
    const m = String(url).match(/(?:youtu\.be\/|v=|\/live\/|embed\/)([\w-]{11})/);
    return m ? 'https://www.youtube.com/embed/' + m[1] : '';
  }
  function watch(id) {
    const l = lives.find(x => x.id === id); if (!l) return;
    const emb = l.platform === 'youtube' ? ytEmbed(l.url) : '';
    if (emb) {
      openModal(`<iframe class="player" src="${emb}" allowfullscreen allow="autoplay; encrypted-media"></iframe>
        <div class="row2"><button class="btn dark" data-close>${T('close')}</button></div>`);
    } else if (l.url) {
      window.open(l.url, '_blank', 'noopener');
    } else {
      window.open(VMC_CONFIG.social[l.platform] || '#', '_blank', 'noopener');
    }
  }

  /* ---------- Cart ---------- */
  const saveCart = () => store.set('vmc_cart', cart);
  function addToCart(id) {
    const it = cart.find(c => c.id === id);
    it ? it.qty++ : cart.push({ id, qty: 1 });
    saveCart(); renderCart(); toast('✓ ' + L(byId(id).name));
    track('AddToCart', { items: pxItems(id, 1), value: byId(id).price });
  }
  const totals = () => {
    const sub = cart.reduce((s, c) => s + (byId(c.id) ? byId(c.id).price * c.qty : 0), 0);
    const ship = !cart.length || sub >= VMC_CONFIG.freeShippingFrom ? 0 : VMC_CONFIG.shippingFee;
    return { sub, ship, total: sub + ship };
  };
  function renderCart() {
    cart = cart.filter(c => byId(c.id));
    $('#cartCount').textContent = cart.reduce((s, c) => s + c.qty, 0);
    $('#items').innerHTML = cart.length ? cart.map(c => {
      const p = byId(c.id);
      return `<div class="item"><div class="em">${p.emoji || '🛍️'}</div>
        <div><h4>${esc(L(p.name))}</h4><div class="pr">${money(p.price)}</div>
          <div class="qty"><button data-q="${c.id}" data-d="-1">−</button><b>${c.qty}</b><button data-q="${c.id}" data-d="1">+</button></div></div>
        <button class="rm" data-rm="${c.id}">${T('remove')}</button></div>`;
    }).join('') : `<p class="empty">${T('cart_empty')}</p>`;
    const t = totals();
    const need = Math.max(0, VMC_CONFIG.freeShippingFrom - t.sub), pct = Math.min(100, Math.round(t.sub / VMC_CONFIG.freeShippingFrom * 100));
    const shipEl = $('#shipBar'); shipEl.hidden = !cart.length;
    shipEl.className = 'ship' + (need ? '' : ' done');
    shipEl.innerHTML = (need ? esc(T('ship_more').replace('%X%', money(need))) : esc(T('ship_ok'))) + `<div class="bar2"><i style="width:${pct}%"></i></div>`;
    const qty = cart.reduce((s, c) => s + c.qty, 0);
    $('#cartCount').setAttribute('aria-label', qty + ' ' + T('items'));
    $('#cbCount').textContent = qty; $('#cbTotal').textContent = money(t.total);
    $('#cartBar').hidden = !cart.length; document.body.classList.toggle('has-cartbar', !!cart.length);
    $('#sum').innerHTML = cart.length ? `
      <div class="row"><span>${T('subtotal')}</span><span>${money(t.sub)}</span></div>
      <div class="row"><span>${T('shipping')}</span><span>${t.ship ? money(t.ship) : T('free')}</span></div>
      <div class="row t"><span>${T('total')}</span><span>${money(t.total)}</span></div>
      <button class="btn primary" data-checkout>${T('checkout')}</button>` : '';
  }
  let lastFocus = null;
  const openCart = o => {
    const d = $('#drawer'); if (o && !d.classList.contains('open')) lastFocus = document.activeElement;
    d.classList.toggle('open', o); d.setAttribute('aria-hidden', String(!o)); $('#overlay').classList.toggle('open', o);
    if (o) setTimeout(() => $('#closeCart').focus(), 60); else if (lastFocus && !$('#modal').classList.contains('open')) { try { lastFocus.focus(); } catch (e) {} }
  };

  /* ---------- Checkout (COD) ---------- */
  let modalFocus = null;
  function openModal(html) {
    if (!$('#modal').classList.contains('open')) modalFocus = document.activeElement;
    $('#modalBox').innerHTML = html; $('#modal').classList.add('open'); $('#modal').setAttribute('aria-hidden', 'false'); $('#overlay').classList.add('open');
    setTimeout(() => { const f = $('#modalBox input,#modalBox select,#modalBox textarea,#modalBox button,#modalBox a[href]'); (f || $('#modalBox')).focus({ preventScroll: true }); }, 60);
  }
  function closeModal() {
    const was = $('#modal').classList.contains('open');
    $('#modal').classList.remove('open'); $('#modal').setAttribute('aria-hidden', 'true'); if (!$('#drawer').classList.contains('open')) $('#overlay').classList.remove('open'); $('#modalBox').innerHTML = '';
    if (was && modalFocus) { try { modalFocus.focus({ preventScroll: true }); } catch (e) {} modalFocus = null; }
  }
  document.addEventListener('keydown', e => {   // حبس التنقل بـ Tab داخل النافذة المفتوحة
    if (e.key !== 'Tab') return;
    const box = $('#modal').classList.contains('open') ? $('#modalBox') : $('#drawer').classList.contains('open') ? $('#drawer') : null; if (!box) return;
    const f = [...box.querySelectorAll('a[href],button:not([disabled]),input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter(x => x.offsetParent !== null);
    if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && (document.activeElement === first || !box.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && (document.activeElement === last || !box.contains(document.activeElement))) { e.preventDefault(); first.focus(); }
  });
  function checkout() {
    openCart(false);
    const t = totals();
    track('InitiateCheckout', { items: cart.map(c => pxItems(c.id, c.qty)[0]).filter(Boolean), value: t.total });
    openModal(`<h3>${T('co_title')}</h3>
      <form id="coForm" novalidate>
        <div class="field"><label>${T('name')} *</label><input name="name" required autocomplete="name"></div>
        <div class="field"><label>${T('phone')} *</label><input name="phone" type="tel" placeholder="06XXXXXXXX" required autocomplete="tel"></div>
        <div class="field"><label>${T('city')} *</label><select name="city">${VMC_CITIES.map(c => `<option>${c}</option>`).join('')}</select></div>
        <div class="field"><label>${T('address')} *</label><input name="address" required autocomplete="street-address"></div>
        <div class="field"><label>${T('notes')}</label><textarea name="notes" rows="2"></textarea></div>
        <div class="pay">💵 ${T('cod')} — <span style="margin-inline-start:auto">${money(t.total)}</span></div>
        <div class="err" id="err">${T('err_fill')}</div>
        <div class="row2"><button type="button" class="btn dark" data-close>${T('cancel')}</button>
        <button type="submit" class="btn primary">${T('confirm')}</button></div>
      </form>`);
    $('#coForm').addEventListener('submit', async e => {
      e.preventDefault();
      const f = new FormData(e.target);
      const name = String(f.get('name')).trim(), phone = String(f.get('phone')).replace(/[\s.-]/g, ''), addr = String(f.get('address')).trim();
      if (name.length < 3 || !/^(\+212|00212|0)[5-7]\d{8}$/.test(phone) || addr.length < 5) { $('#err').style.display = 'block'; return; }
      const btn = e.target.querySelector('[type=submit]'); btn.disabled = true;
      const lines = cart.map(c => ({ id: c.id, qty: c.qty }));
      const order = {
        id: '', date: new Date().toISOString(), status: 'new',
        name, phone, city: f.get('city'), address: addr, notes: String(f.get('notes') || '').trim(),
        items: cart.map(c => ({ id: c.id, name: L(byId(c.id).name), price: byId(c.id).price, qty: c.qty })),
        subtotal: t.sub, shipping: t.ship, total: t.total, payment: 'COD', lang, utm: (window.VMCPixels && VMCPixels.utm()) || {}
      };
      let saved = false;
      if (HTTP) {
        try {
          const r = await fetch('api/orders', { method: 'POST', headers: { 'content-type': 'application/json' },
            body: JSON.stringify({ name, phone, city: order.city, address: addr, notes: order.notes, items: lines, lang, utm: order.utm }) });
          if (r.ok) { const j = await r.json(); order.id = j.id; order.subtotal = j.subtotal; order.shipping = j.shipping; order.total = j.total; saved = true; }
          else if (r.status === 429) { $('#err').textContent = T('err_many'); $('#err').style.display = 'block'; btn.disabled = false; return; }
          else if (r.status === 422) { $('#err').textContent = T('err_fill'); $('#err').style.display = 'block'; btn.disabled = false; return; }
        } catch (err) { /* لا خادم: نحفظ محلياً */ }
      }
      if (!saved) {
        order.id = 'VMC-' + String(Date.now()).slice(-6);
        const orders = store.get('vmc_orders', []); orders.unshift(order); store.set('vmc_orders', orders);
      }
      track('Purchase', { items: order.items.map(i => ({ id: i.id, name: i.name, price: i.price, qty: i.qty })), value: order.total, orderId: order.id });
      cart = []; saveCart(); renderCart();
      const msg = `VMC ${order.id}\n` + order.items.map(i => `• ${i.name} x${i.qty}`).join('\n') + `\n${T('total')}: ${money(order.total)}\n${order.name} – ${order.phone}\n${order.city}, ${order.address}`;
      openModal(`<div class="ok"><div class="big">🎉</div><h3>${T('ok_title')}</h3>
        <div>${T('ok_text')}</div><div class="num">${esc(order.id)}</div><p>${T('ok_text2')}</p><br>
        <div class="row2"><a class="btn primary" target="_blank" rel="noopener" href="https://wa.me/${VMC_CONFIG.whatsapp}?text=${encodeURIComponent(msg)}">💬 ${T('ok_wa')}</a>
        <button class="btn dark" data-close>${T('close')}</button></div></div>`);
    });
  }

  /* ---------- نافذة تفاصيل المنتج ---------- */
  function viewProduct(id) {
    const p = byId(id); if (!p) return;
    const bgs = ['#FFE9EF', '#FFF1DD', '#EDE7FF', '#E6F1FF', '#E6F8EE', '#FFEAE5'];
    const vis = p.image ? `<img src="${esc(p.image)}" alt="${esc(L(p.name))}" style="width:100%;height:100%;object-fit:cover">` : `<span style="font-size:110px">${p.emoji || '🛍️'}</span>`;
    const url = site() + '/p/' + lang + '/' + p.id + '.html';
    openModal(`<div style="aspect-ratio:16/10;border-radius:18px;overflow:hidden;display:grid;place-items:center;background:${bgs[p.id % bgs.length]};margin-bottom:14px">${vis}</div>
      <h3>${esc(L(p.name))}</h3><p style="color:var(--muted);margin-bottom:10px">${esc(L(p.desc))}</p>
      <div class="price" style="margin-bottom:14px"><b>${money(p.price)}</b>${p.old > p.price ? `<s>${money(p.old)}</s>` : ''}</div>
      <div class="pay">💵 ${T('cod')}</div>
      <div class="row2"><button class="btn dark" data-close>${T('close')}</button>
      <button class="btn primary" data-add="${p.id}">🛒 ${T('add')}</button></div>
      <p style="text-align:center;margin-top:12px"><button class="share" data-share="${p.id}">↗ ${T('share')}</button></p>
      <div class="revs" id="revs"></div>
      <p style="text-align:center;margin-top:12px"><a href="https://wa.me/?text=${encodeURIComponent(L(p.name) + ' ' + url)}" target="_blank" rel="noopener" style="font-weight:700;color:var(--red)">↗ WhatsApp</a></p>`);
    track('ViewContent', { items: pxItems(p.id, 1), value: p.price });
    renderReviews(p.id);
  }

    /* ---------- آراء الزبائن ---------- */
  function renderReviews(id) {
    const box = $('#revs'); if (!box) return;
    const r = reviews[id] || [];
    box.innerHTML = `<h4>${T('rev_title')} ${starsHTML(id)}</h4>` +
      (r.length ? r.slice(0, 5).map(x => `<div class="rev"><span class="stars">${'★'.repeat(x.rating)}${'☆'.repeat(5 - x.rating)}</span> <b>${esc(x.name)}</b><br>${esc(x.comment)}</div>`).join('') : `<p style="color:var(--muted);font-size:14px">${T('rev_none')}</p>`) +
      `<form class="revform" id="revForm"><b>${T('rev_write')}</b>
        <select name="rating"><option value="5">★★★★★</option><option value="4">★★★★☆</option><option value="3">★★★☆☆</option><option value="2">★★☆☆☆</option><option value="1">★☆☆☆☆</option></select>
        <input name="name" placeholder="${T('rev_name')}" maxlength="40" required>
        <textarea name="comment" rows="2" placeholder="${T('rev_comment')}" maxlength="500" required></textarea>
        <button class="btn dark" style="padding:10px">${T('rev_send')}</button></form>`;
    $('#revForm').addEventListener('submit', async e => {
      e.preventDefault(); if (!HTTP) return toast(T('rev_need_server'));
      const f = Object.fromEntries(new FormData(e.target));
      try {
        const r2 = await fetch('api/reviews', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ productId: id, rating: +f.rating, name: f.name, comment: f.comment }) });
        if (r2.ok) { e.target.reset(); toast(T('rev_thanks')); } else toast(T('err_fill'));
      } catch (err) { toast(T('rev_need_server')); }
    });
  }

  /* ---------- تتبّع الطلب ---------- */
  const STEPS = ['new', 'confirmed', 'shipped', 'delivered'];
  const normPhone = v => String(v).replace(/[\s.-]/g, '').replace(/^(\+212|00212)/, '0');
  function openTrack() {
    openModal(`<h3>📦 ${T('track_title')}</h3>
      <form id="trForm"><div class="field"><label>${T('track_id')}</label><input name="id" required placeholder="VMC-XXXXXX" style="text-transform:uppercase"></div>
      <div class="field"><label>${T('track_phone')}</label><input name="phone" type="tel" required placeholder="06XXXXXXXX"></div>
      <div class="err" id="trErr">${T('track_none')}</div><div id="trRes"></div>
      <div class="row2"><button type="button" class="btn dark" data-close>${T('close')}</button><button class="btn primary">${T('track_go')}</button></div></form>`);
    $('#trForm').addEventListener('submit', async e => {
      e.preventDefault(); $('#trErr').style.display = 'none'; $('#trRes').innerHTML = '';
      const f = Object.fromEntries(new FormData(e.target)); const id = f.id.trim().toUpperCase(); let o = null;
      if (HTTP) { try { const r = await fetch('api/track?id=' + encodeURIComponent(id) + '&phone=' + encodeURIComponent(f.phone)); if (r.ok) o = await r.json(); } catch (err) {} }
      if (!o) o = store.get('vmc_orders', []).find(x => String(x.id).toUpperCase() === id && normPhone(x.phone) === normPhone(f.phone)) || null;
      if (!o) { $('#trErr').style.display = 'block'; return; }
      const idx = STEPS.indexOf(o.status);
      $('#trRes').innerHTML = `<p><b>${esc(o.id)}</b> — ${T('st_' + o.status)}</p>
        <div class="steps">${STEPS.map((x, i) => `<i class="${idx >= i ? 'on' : ''}"></i>`).join('')}</div>
        ${o.carrier ? `<p>${T('track_carrier')}: <b>${esc(o.carrier)}</b></p>` : ''}${o.tracking ? `<p>${T('track_num')}: <b>${esc(o.tracking)}</b> ${o.trackUrl ? `<a href="${esc(o.trackUrl)}" target="_blank" rel="noopener" style="color:var(--red);font-weight:700">↗</a>` : ''}</p>` : ''}`;
    });
  }

  /* ---------- سياسات ---------- */
  function openPolicy(k) {
    const txt = T(k + '_txt').replace('%D%', VMC_CONFIG.deliveryDays).replace('%F%', VMC_CONFIG.freeShippingFrom).replace('%S%', VMC_CONFIG.shippingFee).replace('%R%', VMC_CONFIG.returnDays);
    const title = { delivery: 'p_delivery', returns: 'p_returns', faq: 'p_faq', terms: 'p_terms', privacy: 'p_privacy' }[k];
    openModal(`<div class="pol"><h3>${T(title)}</h3><p>${esc(txt)}</p><br><div class="row2"><button class="btn dark" data-close>${T('close')}</button></div></div>`);
  }

  /* ---------- النشرة البريدية ---------- */
  $('#newsForm').addEventListener('submit', async e => {
    e.preventDefault(); const v = $('#newsIn').value.trim(), msg = $('#newsMsg');
    const okMail = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v), okTel = /^(\+212|00212|0)[5-7]\d{8}$/.test(v.replace(/[\s.-]/g, ''));
    if (!okMail && !okTel) { msg.textContent = T('news_err'); return; }
    let done = false;
    if (HTTP) { try { done = (await fetch('api/subscribe', { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ contact: v }) })).ok; } catch (err) {} }
    if (!done) { const subs = store.get('vmc_subs', []); subs.push({ contact: v, date: new Date().toISOString() }); store.set('vmc_subs', subs); }
    msg.textContent = T('news_ok'); $('#newsIn').value = '';
  });

  async function shareProduct(id) {
    const p = byId(id); if (!p) return; const url = site() + '/p/' + lang + '/' + p.id + '.html';
    try { if (navigator.share) { await navigator.share({ title: L(p.name), text: L(p.name) + ' – ' + money(p.price), url }); return; } } catch (e) { if (e && e.name === 'AbortError') return; }
    try { await navigator.clipboard.writeText(url); toast(T('copied')); } catch (e) { window.prompt(T('share'), url); }
  }

  /* ---------- Toast ---------- */
  let tt; function toast(m) { const el = $('#toast'); el.textContent = m; el.classList.add('show'); clearTimeout(tt); tt = setTimeout(() => el.classList.remove('show'), 1800); }

  /* ---------- Events ---------- */
  document.addEventListener('click', e => {
    const t = e.target.closest('button,a,[data-add],[data-view],[data-wish],[data-tile]'); if (!t) return;
    const ds = t.dataset || {};
    if (ds.l) { lang = ds.l; store.set('vmc_lang', lang); applyLang(); }
    else if (ds.c) { state.cat = ds.c; renderCats(); renderProducts(); }
    else if (ds.tile) { state.cat = ds.tile; renderCats(); renderProducts(); $('#shop').scrollIntoView({ behavior: 'smooth' }); }
    else if (ds.share) shareProduct(+ds.share)
    else if (t.id === 'cartBar') openCart(true)
    else if (t.id === 'toTop') window.scrollTo({ top: 0, behavior: 'smooth' })
    else if (ds.wish) { toggleWish(+ds.wish); }
    else if (ds.view) viewProduct(+ds.view);
    else if (t.hasAttribute('data-track')) { e.preventDefault(); $('#nav').classList.remove('open'); openTrack(); }
    else if (ds.policy) { e.preventDefault(); openPolicy(ds.policy); }
    else if (t.id === 'openWish') { state.cat = 'wish'; renderCats(); renderProducts(); $('#shop').scrollIntoView({ behavior: 'smooth' }); }
    else if (ds.add) addToCart(+ds.add);
    else if (ds.q) { const it = cart.find(c => c.id === +ds.q); it.qty += +ds.d; if (it.qty < 1) cart = cart.filter(c => c !== it); saveCart(); renderCart(); }
    else if (ds.rm) { cart = cart.filter(c => c.id !== +ds.rm); saveCart(); renderCart(); }
    else if (ds.watch) watch(+ds.watch);
    else if (t.hasAttribute('data-checkout')) checkout();
    else if (t.hasAttribute('data-close')) closeModal();
    else if (t.id === 'openCart') openCart(true);
    else if (t.id === 'closeCart') openCart(false);
    else if (t.id === 'burger') { const o = $('#nav').classList.toggle('open'); t.setAttribute('aria-expanded', String(o)); }
    else if (t.closest('#nav')) $('#nav').classList.remove('open');
  });
  $('#overlay').addEventListener('click', () => { closeModal(); openCart(false); });
  document.addEventListener('keydown', e => { if (e.key === 'Escape') { closeModal(); openCart(false); } });
  $('#q').addEventListener('input', e => { state.q = e.target.value.trim(); renderProducts(); });
  $('#sort').addEventListener('change', e => { state.sort = e.target.value; renderProducts(); });
  if (!HTTP) window.addEventListener('storage', () => { products =store.get('vmc_products', null) || VMC_DEFAULT_PRODUCTS; lives = store.get('vmc_lives', null) || VMC_DEFAULT_LIVES; applyLang(); });

  if (!$('#shipBar')) { const s = document.createElement('div'); s.id = 'shipBar'; s.hidden = true; $('#items').parentNode.insertBefore(s, $('#items')); }
  const wa = 'https://wa.me/' + VMC_CONFIG.whatsapp;
  $('#waFloat').href = wa; $('#waContact').href = wa;
  window.VMCApp = { addToCart: id => addToCart(id), viewProduct: id => viewProduct(id) };
  document.documentElement.classList.add('js-rv');
  applyLang(true);
  const snap = () => JSON.stringify([products, lives, seo, reviews]);
  const before = snap();
  loadRemote().then(() => {
    if (snap() !== before) applyLang();
    if (window.VMCPixels) VMCPixels.init(pixels);
    const pid = +qp.get('product');
    if (pid && byId(pid)) { viewProduct(pid); }
  });

  /* ---------- لمسات: ظهور تدريجي، خلفية كسولة، زر الأعلى، Service Worker ---------- */
  try {
    $$('.sec-head,.feat,.news .container,.cat-tiles,.contact .container').forEach(el => el.classList.add('rv'));
    const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
    if ('IntersectionObserver' in window && !reduce) {
      const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px' });
      $$('.rv').forEach(el => io.observe(el));
      const bg = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('bg-on'); bg.disconnect(); } }), { rootMargin: '600px' });
      bg.observe($('#live'));
    } else { $$('.rv').forEach(el => el.classList.add('in')); $('#live').classList.add('bg-on'); }
    let tick2 = false;
    addEventListener('scroll', () => { if (tick2) return; tick2 = true; requestAnimationFrame(() => { $('#toTop').hidden = scrollY < 900; tick2 = false; }); }, { passive: true });
    if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost')) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));
  } catch (e) {}
})();
