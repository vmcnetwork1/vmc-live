/* VMC – Vision Media Commerce | بيانات المتجر والترجمات */
const VMC_CONFIG = {
  siteUrl: 'https://www.vmc.ma',     // عنوان موقعك النهائي (للسيو وsitemap)
  currencyCode: 'MAD',
  currency: { ar: 'درهم', fr: 'MAD', en: 'MAD' },
  whatsapp: '212600000000',          // غيّر الرقم (بصيغة دولية بدون +)
  adminPassword: 'vmc2026',          // كلمة سر لوحة التحكم (تجريبية – غيّرها)
  freeShippingFrom: 500,
  shippingFee: 30,
  social: {
    youtube: 'https://youtube.com/',
    facebook: 'https://facebook.com/',
    tiktok: 'https://tiktok.com/',
    instagram: 'https://instagram.com/'
  }
};

const VMC_CITIES = ['Casablanca','Rabat','Marrakech','Fès','Tanger','Agadir','Meknès','Oujda','Kénitra','Tétouan','Salé','Témara','Mohammedia','El Jadida','Béni Mellal','Nador','Laâyoune','Autre'];

const VMC_CATEGORIES = [
  { id: 'electronics', icon: '📱', name: { ar: 'إلكترونيات', fr: 'Électronique', en: 'Electronics' } },
  { id: 'fashion',     icon: '👗', name: { ar: 'أزياء وموضة', fr: 'Mode', en: 'Fashion' } },
  { id: 'home',        icon: '🏠', name: { ar: 'المنزل والمطبخ', fr: 'Maison & Cuisine', en: 'Home & Kitchen' } },
  { id: 'beauty',      icon: '🌸', name: { ar: 'الجمال والعناية', fr: 'Beauté & Soins', en: 'Beauty & Care' } },
  { id: 'games',       icon: '🎮', name: { ar: 'ألعاب وإكسسوارات', fr: 'Jeux & Accessoires', en: 'Games & Accessories' } },
  { id: 'ai',          icon: '🤖', name: { ar: 'الذكاء الاصطناعي', fr: 'IA & Tech', en: 'AI & Tech' } },
  { id: 'deals',       icon: '🏷️', name: { ar: 'عروض وتخفيضات', fr: 'Offres & Promos', en: 'Deals & Offers' } }
];

const VMC_DEFAULT_PRODUCTS = [
  { id: 1, cat: 'electronics', emoji: '🎧', price: 449, old: 649, live: true,
    name: { ar: 'سماعات لاسلكية بخاصية عزل الضوضاء', fr: 'Casque sans fil à réduction de bruit', en: 'Noise-Cancelling Wireless Headphones' },
    desc: { ar: 'صوت نقي وبطارية تدوم 30 ساعة.', fr: 'Son pur et 30 h d’autonomie.', en: 'Pure sound and 30-hour battery.' } },
  { id: 2, cat: 'electronics', emoji: '⌚', price: 590, old: 790, live: true,
    name: { ar: 'ساعة ذكية رياضية', fr: 'Montre connectée sport', en: 'Sport Smartwatch' },
    desc: { ar: 'تتبع النشاط ونبضات القلب والإشعارات.', fr: 'Suivi d’activité, rythme cardiaque, notifications.', en: 'Activity, heart rate and notifications.' } },
  { id: 3, cat: 'electronics', emoji: '📱', price: 2290, old: 2590, live: false,
    name: { ar: 'هاتف ذكي 128 جيجا', fr: 'Smartphone 128 Go', en: 'Smartphone 128 GB' },
    desc: { ar: 'شاشة واسعة وكاميرا متقدمة.', fr: 'Grand écran et appareil photo avancé.', en: 'Large display and advanced camera.' } },
  { id: 4, cat: 'fashion', emoji: '👟', price: 349, old: 449, live: true,
    name: { ar: 'حذاء رياضي أبيض', fr: 'Baskets blanches', en: 'White Sneakers' },
    desc: { ar: 'خفيف ومريح لكل يوم.', fr: 'Léger et confortable au quotidien.', en: 'Light and comfortable every day.' } },
  { id: 5, cat: 'fashion', emoji: '👜', price: 279, old: 0, live: false,
    name: { ar: 'حقيبة يد أنيقة', fr: 'Sac à main élégant', en: 'Elegant Handbag' },
    desc: { ar: 'جلد صناعي عالي الجودة.', fr: 'Similicuir de haute qualité.', en: 'High-quality faux leather.' } },
  { id: 6, cat: 'fashion', emoji: '🧥', price: 399, old: 520, live: false,
    name: { ar: 'جلابة عصرية', fr: 'Djellaba moderne', en: 'Modern Djellaba' },
    desc: { ar: 'تصميم مغربي بلمسة عصرية.', fr: 'Design marocain, touche moderne.', en: 'Moroccan design, modern touch.' } },
  { id: 7, cat: 'home', emoji: '🍳', price: 799, old: 990, live: true,
    name: { ar: 'قلاية هوائية 5 لتر', fr: 'Friteuse à air 5 L', en: 'Air Fryer 5 L' },
    desc: { ar: 'طبخ صحي بدون زيت تقريباً.', fr: 'Cuisson saine, presque sans huile.', en: 'Healthy cooking with little oil.' } },
  { id: 8, cat: 'home', emoji: '🍲', price: 329, old: 0, live: false,
    name: { ar: 'طاجين عصري للطبخ', fr: 'Tajine de cuisson moderne', en: 'Modern Cooking Tajine' },
    desc: { ar: 'يحافظ على النكهة الأصيلة.', fr: 'Préserve la saveur authentique.', en: 'Keeps the authentic flavor.' } },
  { id: 9, cat: 'beauty', emoji: '🧴', price: 189, old: 240, live: true,
    name: { ar: 'زيت الأرغان الطبيعي', fr: 'Huile d’argan naturelle', en: 'Natural Argan Oil' },
    desc: { ar: 'للبشرة والشعر، مستخرج بالعصر البارد.', fr: 'Peau et cheveux, pressée à froid.', en: 'Skin and hair, cold-pressed.' } },
  { id: 10, cat: 'beauty', emoji: '💄', price: 129, old: 0, live: false,
    name: { ar: 'مجموعة مكياج', fr: 'Coffret maquillage', en: 'Makeup Set' },
    desc: { ar: 'ألوان متنوعة تدوم طويلاً.', fr: 'Teintes variées longue tenue.', en: 'Varied long-lasting shades.' } },
  { id: 11, cat: 'games', emoji: '🎮', price: 399, old: 499, live: false,
    name: { ar: 'يد تحكم لاسلكية', fr: 'Manette sans fil', en: 'Wireless Controller' },
    desc: { ar: 'متوافقة مع الحاسوب والهاتف.', fr: 'Compatible PC et mobile.', en: 'Compatible with PC and mobile.' } },
  { id: 12, cat: 'ai', emoji: '🤖', price: 349, old: 0, live: true,
    name: { ar: 'مساعد صوتي ذكي', fr: 'Assistant vocal intelligent', en: 'Smart Voice Assistant' },
    desc: { ar: 'تحكم في منزلك بصوتك.', fr: 'Pilotez votre maison à la voix.', en: 'Control your home by voice.' } }
];

const VMC_DEFAULT_LIVES = [
  { id: 1, platform: 'youtube',   title: { ar: 'بث مباشر: أفضل عروض الإلكترونيات', fr: 'Live : meilleures offres électronique', en: 'Live: top electronics deals' }, url: '', products: [1, 2], status: 'live' },
  { id: 2, platform: 'tiktok',    title: { ar: 'جلسة الموضة والجمال', fr: 'Session mode & beauté', en: 'Fashion & beauty session' }, url: '', products: [4, 9], status: 'soon' },
  { id: 3, platform: 'instagram', title: { ar: 'مطبخك الذكي', fr: 'Votre cuisine intelligente', en: 'Your smart kitchen' }, url: '', products: [7, 8], status: 'soon' },
  { id: 4, platform: 'facebook',  title: { ar: 'تخفيضات نهاية الأسبوع', fr: 'Promos du week-end', en: 'Weekend deals' }, url: '', products: [3, 11], status: 'soon' }
];

const VMC_I18N = {
  ar: {
    dir: 'rtl', brandSub: 'شبكة التسوق المباشر',
    nav_home: 'الرئيسية', nav_shop: 'المتجر', nav_live: 'البث المباشر', nav_contact: 'تواصل',
    slogan: 'شوف. اكتشف. تسوّق.',
    hero_title: 'متجرك في بث مباشر', hero_text: 'شاهد المنتجات مباشرة، اسأل البائع، واطلب بالدفع عند الاستلام في كل مدن المغرب.',
    hero_cta: 'تسوّق الآن', hero_cta2: 'شاهد البث',
    f1_t: 'بثوث مباشرة', f1_d: 'عيش التجربة في الوقت الحقيقي',
    f2_t: 'متجر إلكتروني', f2_d: 'آلاف المنتجات في مكان واحد',
    f3_t: 'الدفع عند الاستلام', f3_d: 'ادفع عندما يصلك طلبك',
    f4_t: 'توصيل سريع', f4_d: 'لجميع مدن المغرب',
    f5_t: 'ذكاء اصطناعي', f5_d: 'تجربة تسوق أذكى',
    shop_title: 'تسوّق حسب القسم', all: 'الكل', search: 'ابحث عن منتج…',
    sort: 'ترتيب', sort_def: 'الافتراضي', sort_low: 'السعر: الأقل', sort_high: 'السعر: الأعلى',
    add: 'أضف إلى السلة', in_live: 'في البث', no_results: 'لا توجد منتجات مطابقة.',
    live_title: 'التسوق المباشر', live_sub: 'تابعنا على المنصات واشترِ المنتجات المعروضة مباشرة',
    live_now: 'مباشر الآن', live_soon: 'قريباً', watch: 'شاهد البث', featured: 'منتجات البث',
    cart: 'سلة المشتريات', cart_empty: 'سلتك فارغة.', subtotal: 'المجموع الفرعي', shipping: 'التوصيل', free: 'مجاني', total: 'الإجمالي',
    checkout: 'إتمام الطلب', remove: 'حذف',
    co_title: 'معلومات التوصيل', name: 'الاسم الكامل', phone: 'رقم الهاتف', city: 'المدينة', address: 'العنوان', notes: 'ملاحظات (اختياري)',
    cod: 'الدفع عند الاستلام', confirm: 'تأكيد الطلب', cancel: 'إلغاء',
    ok_title: 'تم استلام طلبك!', ok_text: 'رقم الطلب', ok_text2: 'سنتصل بك قريباً لتأكيد التوصيل.', ok_wa: 'تأكيد عبر واتساب', close: 'إغلاق',
    err_fill: 'المرجو ملء جميع الحقول المطلوبة بشكل صحيح.',
    contact_title: 'تواصل معنا', contact_text: 'نحن هنا للإجابة عن أسئلتك.',
    rights: 'جميع الحقوق محفوظة', tagline: 'المغرب … إلى العالم'
  },
  fr: {
    dir: 'ltr', brandSub: 'LIVE SHOPPING NETWORK',
    nav_home: 'Accueil', nav_shop: 'Boutique', nav_live: 'Lives', nav_contact: 'Contact',
    slogan: 'Regarde. Découvre. Achète.',
    hero_title: 'Votre boutique en direct', hero_text: 'Découvrez les produits en live, posez vos questions et commandez avec paiement à la livraison partout au Maroc.',
    hero_cta: 'Acheter maintenant', hero_cta2: 'Voir les lives',
    f1_t: 'Lives directs', f1_d: 'Vivez l’expérience en temps réel',
    f2_t: 'Boutique en ligne', f2_d: 'Des milliers de produits',
    f3_t: 'Paiement à la livraison', f3_d: 'Payez à la réception',
    f4_t: 'Livraison rapide', f4_d: 'Dans tout le Maroc',
    f5_t: 'IA & Innovation', f5_d: 'Un achat plus intelligent',
    shop_title: 'Acheter par catégorie', all: 'Tout', search: 'Rechercher un produit…',
    sort: 'Trier', sort_def: 'Par défaut', sort_low: 'Prix croissant', sort_high: 'Prix décroissant',
    add: 'Ajouter au panier', in_live: 'En live', no_results: 'Aucun produit trouvé.',
    live_title: 'Live Shopping', live_sub: 'Suivez-nous sur les plateformes et achetez les produits présentés',
    live_now: 'En direct', live_soon: 'Bientôt', watch: 'Regarder', featured: 'Produits du live',
    cart: 'Panier', cart_empty: 'Votre panier est vide.', subtotal: 'Sous-total', shipping: 'Livraison', free: 'Gratuite', total: 'Total',
    checkout: 'Commander', remove: 'Retirer',
    co_title: 'Informations de livraison', name: 'Nom complet', phone: 'Téléphone', city: 'Ville', address: 'Adresse', notes: 'Remarques (facultatif)',
    cod: 'Paiement à la livraison', confirm: 'Confirmer la commande', cancel: 'Annuler',
    ok_title: 'Commande reçue !', ok_text: 'N° de commande', ok_text2: 'Nous vous appellerons bientôt pour confirmer la livraison.', ok_wa: 'Confirmer sur WhatsApp', close: 'Fermer',
    err_fill: 'Veuillez remplir correctement tous les champs obligatoires.',
    contact_title: 'Contactez-nous', contact_text: 'Nous répondons à toutes vos questions.',
    rights: 'Tous droits réservés', tagline: 'Le Maroc … vers le monde'
  },
  en: {
    dir: 'ltr', brandSub: 'LIVE SHOPPING NETWORK',
    nav_home: 'Home', nav_shop: 'Shop', nav_live: 'Live', nav_contact: 'Contact',
    slogan: 'Watch. Discover. Shop.',
    hero_title: 'Your store, live', hero_text: 'Watch products live, ask the host and order with cash on delivery anywhere in Morocco.',
    hero_cta: 'Shop now', hero_cta2: 'Watch live',
    f1_t: 'Live streams', f1_d: 'Experience it in real time',
    f2_t: 'Online store', f2_d: 'Thousands of products',
    f3_t: 'Cash on delivery', f3_d: 'Pay when it arrives',
    f4_t: 'Fast delivery', f4_d: 'All across Morocco',
    f5_t: 'AI & Innovation', f5_d: 'Smarter shopping',
    shop_title: 'Shop by category', all: 'All', search: 'Search a product…',
    sort: 'Sort', sort_def: 'Default', sort_low: 'Price: low to high', sort_high: 'Price: high to low',
    add: 'Add to cart', in_live: 'In live', no_results: 'No matching products.',
    live_title: 'Live Shopping', live_sub: 'Follow us on the platforms and buy the featured products',
    live_now: 'Live now', live_soon: 'Coming soon', watch: 'Watch', featured: 'Featured products',
    cart: 'Shopping cart', cart_empty: 'Your cart is empty.', subtotal: 'Subtotal', shipping: 'Shipping', free: 'Free', total: 'Total',
    checkout: 'Checkout', remove: 'Remove',
    co_title: 'Delivery information', name: 'Full name', phone: 'Phone', city: 'City', address: 'Address', notes: 'Notes (optional)',
    cod: 'Cash on delivery', confirm: 'Confirm order', cancel: 'Cancel',
    ok_title: 'Order received!', ok_text: 'Order no.', ok_text2: 'We will call you soon to confirm delivery.', ok_wa: 'Confirm on WhatsApp', close: 'Close',
    err_fill: 'Please fill in all required fields correctly.',
    contact_title: 'Contact us', contact_text: 'We are here to answer your questions.',
    rights: 'All rights reserved', tagline: 'Morocco … to the world'
  }
};

/* ===== السيو الافتراضي (يمكن تعديله من لوحة التحكم > التسويق) ===== */
const VMC_DEFAULT_SEO = {
  title: {
    ar: 'VMC – شبكة التسوق المباشر في المغرب | شوف. اكتشف. تسوّق',
    fr: 'VMC – Live Shopping Network au Maroc | Regarde. Découvre. Achète.',
    en: 'VMC – Live Shopping Network in Morocco | Watch. Discover. Shop.'
  },
  description: {
    ar: 'تسوّق من بثوث مباشرة واطلب بالدفع عند الاستلام مع توصيل لجميع مدن المغرب: إلكترونيات، أزياء، المنزل والمطبخ، الجمال والمزيد.',
    fr: 'Achetez en live et payez à la livraison partout au Maroc : électronique, mode, maison & cuisine, beauté et plus encore.',
    en: 'Shop from live streams and pay cash on delivery across Morocco: electronics, fashion, home & kitchen, beauty and more.'
  },
  keywords: {
    ar: 'تسوق مباشر, متجر إلكتروني المغرب, الدفع عند الاستلام, توصيل المغرب, VMC',
    fr: 'live shopping Maroc, boutique en ligne Maroc, paiement à la livraison, livraison Maroc, VMC',
    en: 'live shopping Morocco, online store Morocco, cash on delivery, Morocco delivery, VMC'
  }
};

/* ===== البيكسلات: ضع المعرّفات من لوحة التحكم > التسويق (أو مباشرة هنا) ===== */
const VMC_DEFAULT_PIXELS = {
  meta: '',            // Meta (Facebook/Instagram) Pixel ID
  tiktok: '',          // TikTok Pixel ID
  snapchat: '',        // Snap Pixel ID
  pinterest: '',       // Pinterest Tag ID
  ga4: '',             // Google Analytics 4: G-XXXXXXXXXX
  gtm: '',             // Google Tag Manager: GTM-XXXXXXX
  gadsId: '',          // Google Ads: AW-XXXXXXXXX
  gadsLabel: '',       // Google Ads conversion label (Purchase)
  twitter: '',         // X (Twitter) Pixel ID
  twitterPurchase: '', // X purchase event ID (tw-xxxx-xxxx)
  verifyMeta: '',      // facebook-domain-verification
  verifyGoogle: ''     // google-site-verification
};

/* ===== شركات التوصيل (قابلة للتعديل من لوحة التحكم > التوصيل) =====
   tracking: قالب رابط التتبع، استعمل {n} مكان رقم الشحنة. تحقق من الروابط مع كل شركة. */
const VMC_DEFAULT_CARRIERS = [
  { id: 'amana',    name: 'Amana (Barid Al-Maghrib)', tracking: '', enabled: false },
  { id: 'aramex',   name: 'Aramex',        tracking: 'https://www.aramex.com/track/results?ShipmentNumber={n}', enabled: false },
  { id: 'dhl',      name: 'DHL Express',   tracking: 'https://www.dhl.com/ma-en/home/tracking.html?tracking-id={n}', enabled: false },
  { id: 'cathedis', name: 'Cathedis',      tracking: '', enabled: false },
  { id: 'ozone',    name: 'Ozone Express', tracking: '', enabled: false },
  { id: 'sendit',   name: 'Sendit',        tracking: '', enabled: false },
  { id: 'livo',     name: 'Livo',          tracking: '', enabled: false },
  { id: 'digylog',  name: 'Digylog',       tracking: '', enabled: false },
  { id: 'forcelog', name: 'Forcelog',      tracking: '', enabled: false },
  { id: 'speedaf',  name: 'Speedaf',       tracking: '', enabled: false },
  { id: 'other',    name: 'Autre / Livreur interne', tracking: '', enabled: true }
];

if (typeof module !== 'undefined') module.exports = { VMC_CONFIG, VMC_CITIES, VMC_CATEGORIES, VMC_DEFAULT_PRODUCTS, VMC_DEFAULT_LIVES, VMC_I18N, VMC_DEFAULT_SEO, VMC_DEFAULT_PIXELS, VMC_DEFAULT_CARRIERS };

/* ===== إضافات v3: سياسات + ترجمات الميزات الجديدة ===== */
VMC_CONFIG.deliveryDays = '24–72h';   // عدّل حسب واقع شركة التوصيل
VMC_CONFIG.returnDays = 7;            // عدّل حسب سياسة متجرك
VMC_CONFIG.email = 'contact@vmc.ma';
Object.assign(VMC_I18N.ar, {
  nav_deals: 'عروض اليوم', nav_guide: 'دليل البث', nav_track: 'تتبّع طلبك',
  wish: 'المفضلة', wish_empty: 'لم تضف أي منتج إلى المفضلة بعد.',
  deal_title: 'عروض اليوم', deal_ends: 'ينتهي خلال', off: 'خصم',
  guide_title: 'دليل البث', guide_empty: 'لا توجد بثوث مجدولة حالياً.',
  track_title: 'تتبّع طلبك', track_id: 'رقم الطلب', track_phone: 'رقم الهاتف', track_go: 'تتبّع', track_none: 'لم نعثر على طلب بهذه البيانات.',
  track_carrier: 'شركة التوصيل', track_num: 'رقم التتبع',
  st_new: 'تم استلام الطلب', st_confirmed: 'تم تأكيد الطلب', st_shipped: 'في الطريق إليك', st_delivered: 'تم التسليم', st_returned: 'مرتجع', st_cancelled: 'ملغى',
  rev_title: 'آراء الزبائن', rev_none: 'لا توجد آراء بعد. كن أول من يقيّم هذا المنتج.', rev_write: 'قيّم هذا المنتج', rev_name: 'الاسم', rev_comment: 'تعليقك', rev_send: 'إرسال الرأي',
  rev_thanks: 'شكراً! سيظهر رأيك بعد مراجعته.', rev_need_server: 'التقييم متاح عند تشغيل الخادم.',
  news_title: 'اشترك ليصلك جديدنا', news_text: 'مواعيد البثوث والعروض الحصرية على واتساب أو البريد.', news_ph: 'رقم واتساب أو بريدك', news_btn: 'اشتراك', news_ok: 'تم الاشتراك. شكراً!', news_err: 'أدخل رقماً مغربياً أو بريداً صحيحاً.',
  help: 'المساعدة', p_delivery: 'التوصيل', p_returns: 'الاسترجاع', p_faq: 'أسئلة شائعة', p_terms: 'الشروط', p_privacy: 'الخصوصية', follow: 'تابعنا',
  delivery_txt: 'نوصّل إلى جميع مدن المغرب خلال %D% تقريباً حسب المدينة. التوصيل مجاني للطلبات من %F% MAD، وإلا %S% MAD. الدفع عند الاستلام فقط.',
  returns_txt: 'يمكنك طلب الاسترجاع أو الاستبدال خلال %R% أيام من الاستلام إن كان المنتج بحالته الأصلية. تواصل معنا عبر واتساب برقم الطلب.',
  faq_txt: 'كيف أطلب؟ أضف المنتج للسلة وأكمل بياناتك. هل أدفع مسبقاً؟ لا، الدفع عند الاستلام. هل أتأكد من طلبي؟ نتصل بك للتأكيد، ويمكنك تتبعه من «تتبّع طلبك».',
  terms_txt: 'باستعمالك الموقع توافق على شروط البيع: الأسعار بالدرهم المغربي، وقد تتغير دون إشعار مسبق، ويُؤكَّد الطلب هاتفياً قبل الشحن.',
  privacy_txt: 'نجمع الاسم والهاتف والعنوان لمعالجة طلبك فقط، ولا نبيعها لأي جهة. نستعمل ملفات تعريف الارتباط والبيكسلات بعد موافقتك لقياس إعلاناتنا.'
});
Object.assign(VMC_I18N.fr, {
  nav_deals: 'Offres du jour', nav_guide: 'Guide TV', nav_track: 'Suivre ma commande',
  wish: 'Favoris', wish_empty: 'Aucun favori pour le moment.',
  deal_title: 'Offres du jour', deal_ends: 'Se termine dans', off: 'de remise',
  guide_title: 'Guide des lives', guide_empty: 'Aucun live programmé pour le moment.',
  track_title: 'Suivre ma commande', track_id: 'N° de commande', track_phone: 'Téléphone', track_go: 'Suivre', track_none: 'Aucune commande trouvée avec ces informations.',
  track_carrier: 'Transporteur', track_num: 'N° de suivi',
  st_new: 'Commande reçue', st_confirmed: 'Commande confirmée', st_shipped: 'En route vers vous', st_delivered: 'Livrée', st_returned: 'Retournée', st_cancelled: 'Annulée',
  rev_title: 'Avis clients', rev_none: 'Aucun avis. Soyez le premier à noter ce produit.', rev_write: 'Donner mon avis', rev_name: 'Nom', rev_comment: 'Votre commentaire', rev_send: 'Envoyer',
  rev_thanks: 'Merci ! Votre avis sera publié après vérification.', rev_need_server: 'Les avis nécessitent le serveur.',
  news_title: 'Restez informé', news_text: 'Horaires des lives et offres exclusives par WhatsApp ou e-mail.', news_ph: 'N° WhatsApp ou e-mail', news_btn: 'S’abonner', news_ok: 'Inscription réussie. Merci !', news_err: 'Entrez un numéro marocain ou un e-mail valide.',
  help: 'Aide', p_delivery: 'Livraison', p_returns: 'Retours', p_faq: 'FAQ', p_terms: 'Conditions', p_privacy: 'Confidentialité', follow: 'Suivez-nous',
  delivery_txt: 'Nous livrons dans toutes les villes du Maroc en %D% environ selon la ville. Livraison offerte dès %F% MAD, sinon %S% MAD. Paiement à la livraison uniquement.',
  returns_txt: 'Retour ou échange possible sous %R% jours après réception si le produit est dans son état d’origine. Contactez-nous sur WhatsApp avec votre n° de commande.',
  faq_txt: 'Comment commander ? Ajoutez au panier et renseignez vos informations. Dois-je payer d’avance ? Non, paiement à la livraison. Comment suivre ? Nous vous appelons pour confirmer, puis utilisez « Suivre ma commande ».',
  terms_txt: 'En utilisant ce site vous acceptez nos conditions de vente : prix en dirhams marocains, modifiables sans préavis, commande confirmée par téléphone avant expédition.',
  privacy_txt: 'Nous collectons nom, téléphone et adresse uniquement pour traiter votre commande, sans les revendre. Cookies et pixels uniquement avec votre consentement.'
});
Object.assign(VMC_I18N.en, {
  nav_deals: 'Today’s deals', nav_guide: 'TV guide', nav_track: 'Track order',
  wish: 'Wishlist', wish_empty: 'Your wishlist is empty.',
  deal_title: 'Today’s deals', deal_ends: 'Ends in', off: 'off',
  guide_title: 'Live schedule', guide_empty: 'No scheduled streams right now.',
  track_title: 'Track your order', track_id: 'Order no.', track_phone: 'Phone', track_go: 'Track', track_none: 'No order found with these details.',
  track_carrier: 'Carrier', track_num: 'Tracking no.',
  st_new: 'Order received', st_confirmed: 'Order confirmed', st_shipped: 'On its way', st_delivered: 'Delivered', st_returned: 'Returned', st_cancelled: 'Cancelled',
  rev_title: 'Customer reviews', rev_none: 'No reviews yet. Be the first to review this product.', rev_write: 'Write a review', rev_name: 'Name', rev_comment: 'Your comment', rev_send: 'Submit',
  rev_thanks: 'Thank you! Your review will appear after moderation.', rev_need_server: 'Reviews need the server running.',
  news_title: 'Stay in the loop', news_text: 'Live schedules and exclusive offers via WhatsApp or email.', news_ph: 'WhatsApp number or email', news_btn: 'Subscribe', news_ok: 'Subscribed. Thank you!', news_err: 'Enter a valid Moroccan number or email.',
  help: 'Help', p_delivery: 'Delivery', p_returns: 'Returns', p_faq: 'FAQ', p_terms: 'Terms', p_privacy: 'Privacy', follow: 'Follow us',
  delivery_txt: 'We deliver to all cities in Morocco in about %D% depending on the city. Free delivery from %F% MAD, otherwise %S% MAD. Cash on delivery only.',
  returns_txt: 'Returns or exchanges within %R% days of receipt if the product is in its original condition. Contact us on WhatsApp with your order number.',
  faq_txt: 'How to order? Add to cart and fill in your details. Pay upfront? No, cash on delivery. Tracking? We call to confirm, then use “Track order”.',
  terms_txt: 'By using this site you accept our terms of sale: prices in Moroccan dirhams, subject to change without notice; orders are confirmed by phone before shipping.',
  privacy_txt: 'We collect name, phone and address only to process your order and never sell them. Cookies and pixels are used only with your consent.'
});

/* ===== chat agent strings ===== */
Object.assign(VMC_I18N.ar, { chat_title: 'مساعد VMC', chat_sub: 'يردّ فوراً', chat_hello: 'مرحباً 👋 أنا مساعد VMC. اسألني عن المنتجات، التوصيل، الدفع، أو تتبع طلبك.', chat_ph: 'اكتب رسالتك…', chat_chips: ['اقترح لي منتجاً', 'كم مدة التوصيل؟', 'تتبّع طلبي', 'التحدث مع الفريق'], chat_err: 'تعذّر الاتصال الآن. راسلنا على واتساب.', chat_wa: 'واتساب', chat_add: 'أضف', chat_ai: 'مساعد آلي — قد يخطئ، تأكد من المعلومات المهمة.' });
Object.assign(VMC_I18N.fr, { chat_title: 'Assistant VMC', chat_sub: 'Répond instantanément', chat_hello: 'Bonjour 👋 Je suis l’assistant VMC. Posez-moi vos questions sur les produits, la livraison, le paiement ou le suivi de commande.', chat_ph: 'Écrivez votre message…', chat_chips: ['Conseillez-moi un produit', 'Délai de livraison ?', 'Suivre ma commande', 'Parler à l’équipe'], chat_err: 'Connexion impossible pour le moment. Écrivez-nous sur WhatsApp.', chat_wa: 'WhatsApp', chat_add: 'Ajouter', chat_ai: 'Assistant automatique — peut se tromper, vérifiez les infos importantes.' });
Object.assign(VMC_I18N.en, { chat_title: 'VMC Assistant', chat_sub: 'Replies instantly', chat_hello: 'Hi 👋 I’m the VMC assistant. Ask me about products, delivery, payment or tracking your order.', chat_ph: 'Type your message…', chat_chips: ['Suggest a product', 'Delivery time?', 'Track my order', 'Talk to the team'], chat_err: 'Can’t connect right now. Message us on WhatsApp.', chat_wa: 'WhatsApp', chat_add: 'Add', chat_ai: 'Automated assistant — may make mistakes, verify important info.' });

Object.assign(VMC_I18N.ar, { err_many: 'محاولات كثيرة. انتظر بضع دقائق أو راسلنا على واتساب.' });
Object.assign(VMC_I18N.fr, { err_many: 'Trop de tentatives. Patientez quelques minutes ou écrivez-nous sur WhatsApp.' });
Object.assign(VMC_I18N.en, { err_many: 'Too many attempts. Please wait a few minutes or message us on WhatsApp.' });

Object.assign(VMC_I18N.ar, { skip: 'انتقل إلى المتجر', cat_title: 'اكتشف أقسامنا', items: 'منتج', ship_more: 'أضف %X% للحصول على التوصيل المجاني 🚚', ship_ok: '🎉 توصيلك مجاني!', share: 'مشاركة', copied: 'تم نسخ الرابط', to_top: 'للأعلى' });
Object.assign(VMC_I18N.fr, { skip: 'Aller à la boutique', cat_title: 'Découvrez nos univers', items: 'produits', ship_more: 'Plus que %X% pour la livraison gratuite 🚚', ship_ok: '🎉 Livraison offerte !', share: 'Partager', copied: 'Lien copié', to_top: 'Haut de page' });
Object.assign(VMC_I18N.en, { skip: 'Skip to shop', cat_title: 'Discover our departments', items: 'items', ship_more: 'Add %X% more for free delivery 🚚', ship_ok: '🎉 You get free delivery!', share: 'Share', copied: 'Link copied', to_top: 'Back to top' });
