/* VMC – مدير البيكسلات والتتبع
   المنصات: Meta (Facebook/Instagram) · TikTok · Snapchat · Pinterest · Google (GA4 / Ads / GTM) · X
   الأحداث: ViewContent · AddToCart · InitiateCheckout · Purchase
   لا يُحمَّل أي بيكسل إلا بعد موافقة الزائر (لافتة الكوكيز). */
(function () {
  'use strict';
  var W = window, D = document;
  var cfg = {}, loaded = false, queue = [];
  var CUR = (typeof VMC_CONFIG !== 'undefined' && VMC_CONFIG.currencyCode) || 'MAD';
  var RX = {
    meta: /^\d{5,20}$/, tiktok: /^[A-Z0-9]{10,30}$/i, snapchat: /^[\w-]{8,60}$/, pinterest: /^\d{6,20}$/,
    ga4: /^G-[A-Z0-9]{6,14}$/, gtm: /^GTM-[A-Z0-9]{4,10}$/, gadsId: /^AW-\d{6,14}$/, gadsLabel: /^[\w-]{6,40}$/,
    twitter: /^[a-z0-9]{4,10}$/i, twitterPurchase: /^tw-[\w-]+$/i
  };
  function val(k) { var v = String(cfg[k] || '').trim(); return v && RX[k] && RX[k].test(v) ? v : ''; }
  function anyPixel() { return Object.keys(RX).some(function (k) { return val(k); }); }
  function consent() { try { return localStorage.getItem('vmc_consent'); } catch (e) { return null; } }
  function setConsent(v) { try { localStorage.setItem('vmc_consent', v); } catch (e) {} }

  /* ---- UTM / مصدر الزيارة ---- */
  function captureUTM() {
    try {
      var q = new URLSearchParams(location.search), keys = ['utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term', 'fbclid', 'ttclid', 'gclid', 'ScCid', 'epik'], got = {};
      keys.forEach(function (k) { if (q.get(k)) got[k] = q.get(k).slice(0, 100); });
      if (Object.keys(got).length) sessionStorage.setItem('vmc_utm', JSON.stringify(got));
    } catch (e) {}
  }
  function utm() { try { return JSON.parse(sessionStorage.getItem('vmc_utm') || '{}'); } catch (e) { return {}; } }

  /* ---- verification meta tags (لا تحتاج موافقة) ---- */
  function metaTag(name, content) {
    if (!content || !/^[\w-]{10,120}$/.test(content)) return;
    var m = D.createElement('meta'); m.name = name; m.content = content; D.head.appendChild(m);
  }

  /* ---- تحميل البيكسلات ---- */
  function loadAll() {
    if (loaded) return; loaded = true;
    var id;
    if ((id = val('meta'))) {
      !function (f, b, e, v, n, t, s) { if (f.fbq) return; n = f.fbq = function () { n.callMethod ? n.callMethod.apply(n, arguments) : n.queue.push(arguments); }; if (!f._fbq) f._fbq = n; n.push = n; n.loaded = !0; n.version = '2.0'; n.queue = []; t = b.createElement(e); t.async = !0; t.src = v; s = b.getElementsByTagName(e)[0]; s.parentNode.insertBefore(t, s); }(W, D, 'script', 'https://connect.facebook.net/en_US/fbevents.js');
      W.fbq('init', id); W.fbq('track', 'PageView');
    }
    if ((id = val('tiktok'))) {
      !function (w, d, t) { w.TiktokAnalyticsObject = t; var ttq = w[t] = w[t] || []; ttq.methods = ['page', 'track', 'identify', 'instances', 'debug', 'on', 'off', 'once', 'ready', 'alias', 'group', 'enableCookie', 'disableCookie']; ttq.setAndDefer = function (t, e) { t[e] = function () { t.push([e].concat(Array.prototype.slice.call(arguments, 0))); }; }; for (var i = 0; i < ttq.methods.length; i++) ttq.setAndDefer(ttq, ttq.methods[i]); ttq.instance = function (t) { for (var e = ttq._i[t] || [], n = 0; n < ttq.methods.length; n++) ttq.setAndDefer(e, ttq.methods[n]); return e; }; ttq.load = function (e, n) { var i = 'https://analytics.tiktok.com/i18n/pixel/events.js'; ttq._i = ttq._i || {}; ttq._i[e] = []; ttq._i[e]._u = i; ttq._t = ttq._t || {}; ttq._t[e] = +new Date(); ttq._o = ttq._o || {}; ttq._o[e] = n || {}; var o = document.createElement('script'); o.type = 'text/javascript'; o.async = !0; o.src = i + '?sdkid=' + e + '&lib=' + t; var a = document.getElementsByTagName('script')[0]; a.parentNode.insertBefore(o, a); }; ttq.load(id); ttq.page(); }(W, D, 'ttq');
    }
    if ((id = val('snapchat'))) {
      (function (e, t, n) { if (e.snaptr) return; var a = e.snaptr = function () { a.handleRequest ? a.handleRequest.apply(a, arguments) : a.queue.push(arguments); }; a.queue = []; var s = 'script', r = t.createElement(s); r.async = !0; r.src = n; var u = t.getElementsByTagName(s)[0]; u.parentNode.insertBefore(r, u); })(W, D, 'https://sc-static.net/scevent.min.js');
      W.snaptr('init', id, {}); W.snaptr('track', 'PAGE_VIEW');
    }
    if ((id = val('pinterest'))) {
      !function (e) { if (!W.pintrk) { W.pintrk = function () { W.pintrk.queue.push(Array.prototype.slice.call(arguments)); }; var n = W.pintrk; n.queue = []; n.version = '3.0'; var t = D.createElement('script'); t.async = !0; t.src = e; var r = D.getElementsByTagName('script')[0]; r.parentNode.insertBefore(t, r); } }('https://s.pinimg.com/ct/core.js');
      W.pintrk('load', id); W.pintrk('page');
    }
    if ((id = val('gtm'))) {
      (function (w, d, s, l, i) { w[l] = w[l] || []; w[l].push({ 'gtm.start': new Date().getTime(), event: 'gtm.js' }); var f = d.getElementsByTagName(s)[0], j = d.createElement(s); j.async = true; j.src = 'https://www.googletagmanager.com/gtm.js?id=' + i; f.parentNode.insertBefore(j, f); })(W, D, 'script', 'dataLayer', id);
    }
    var g1 = val('ga4'), g2 = val('gadsId');
    if (g1 || g2) {
      W.dataLayer = W.dataLayer || [];
      W.gtag = function () { W.dataLayer.push(arguments); };
      var s = D.createElement('script'); s.async = true; s.src = 'https://www.googletagmanager.com/gtag/js?id=' + (g1 || g2); D.head.appendChild(s);
      W.gtag('js', new Date());
      if (g1) W.gtag('config', g1);
      if (g2) W.gtag('config', g2);
    }
    if ((id = val('twitter'))) {
      !function (e, t, n, s, u, a) { e.twq || (s = e.twq = function () { s.exe ? s.exe.apply(s, arguments) : s.queue.push(arguments); }, s.version = '1.1', s.queue = [], u = t.createElement(n), u.async = !0, u.src = 'https://static.ads-twitter.com/uwt.js', a = t.getElementsByTagName(n)[0], a.parentNode.insertBefore(u, a)); }(W, D, 'script');
      W.twq('config', id);
    }
    queue.splice(0).forEach(function (a) { send(a[0], a[1]); });
  }

  /* ---- إرسال الأحداث ---- */
  function items(d) { return (d.items || []).map(function (i) { return { id: String(i.id), name: i.name, price: i.price, quantity: i.qty || 1 }; }); }
  function send(ev, d) {
    d = d || {};
    var its = items(d), value = d.value, ids = its.map(function (i) { return i.id; }), n = its.reduce(function (s, i) { return s + i.quantity; }, 0);
    try {
      if (W.fbq) {
        var fb = { ViewContent: 'ViewContent', AddToCart: 'AddToCart', InitiateCheckout: 'InitiateCheckout', Purchase: 'Purchase' }[ev];
        if (fb) W.fbq('track', fb, { content_ids: ids, content_type: 'product', contents: its.map(function (i) { return { id: i.id, quantity: i.quantity, item_price: i.price }; }), value: value, currency: CUR, num_items: n }, d.orderId ? { eventID: d.orderId } : undefined);
      }
      if (W.ttq) {
        var tk = { ViewContent: 'ViewContent', AddToCart: 'AddToCart', InitiateCheckout: 'InitiateCheckout', Purchase: 'CompletePayment' }[ev];
        if (tk) W.ttq.track(tk, { contents: its.map(function (i) { return { content_id: i.id, content_name: i.name, quantity: i.quantity, price: i.price }; }), content_type: 'product', value: value, currency: CUR });
      }
      if (W.snaptr) {
        var sn = { ViewContent: 'VIEW_CONTENT', AddToCart: 'ADD_CART', InitiateCheckout: 'START_CHECKOUT', Purchase: 'PURCHASE' }[ev];
        if (sn) W.snaptr('track', sn, { item_ids: ids, price: value, currency: CUR, number_items: n, transaction_id: d.orderId });
      }
      if (W.pintrk) {
        var pn = { ViewContent: 'pagevisit', AddToCart: 'addtocart', InitiateCheckout: 'checkout', Purchase: 'checkout' }[ev];
        if (pn) W.pintrk('track', pn, { value: value, order_quantity: n, currency: CUR, order_id: d.orderId, line_items: its.map(function (i) { return { product_id: i.id, product_name: i.name, product_price: i.price, product_quantity: i.quantity }; }) });
      }
      var ga = { ViewContent: 'view_item', AddToCart: 'add_to_cart', InitiateCheckout: 'begin_checkout', Purchase: 'purchase' }[ev];
      var gi = its.map(function (i) { return { item_id: i.id, item_name: i.name, price: i.price, quantity: i.quantity }; });
      if (W.gtag && ga) {
        W.gtag('event', ga, { currency: CUR, value: value, items: gi, transaction_id: d.orderId });
        if (ev === 'Purchase' && val('gadsId') && val('gadsLabel')) W.gtag('event', 'conversion', { send_to: val('gadsId') + '/' + val('gadsLabel'), value: value, currency: CUR, transaction_id: d.orderId });
      }
      if (val('gtm') && ga) { W.dataLayer = W.dataLayer || []; W.dataLayer.push({ ecommerce: null }); W.dataLayer.push({ event: ga, ecommerce: { currency: CUR, value: value, transaction_id: d.orderId, items: gi } }); }
      if (W.twq && ev === 'Purchase' && val('twitterPurchase')) W.twq('event', val('twitterPurchase'), { value: value, currency: CUR, contents: its.map(function (i) { return { content_id: i.id, content_price: i.price, num_items: i.quantity }; }), conversion_id: d.orderId });
    } catch (e) { /* لا نكسر المتجر بسبب خطأ تتبع */ }
  }
  function track(ev, d) {
    var c = consent();
    if (c === 'yes') { loaded ? send(ev, d) : (queue.push([ev, d]), loadAll()); }
    else if (c !== 'no' && anyPixel()) queue.push([ev, d]);
  }

  /* ---- لافتة الموافقة ---- */
  var TXT = {
    ar: ['نستخدم ملفات تعريف الارتباط وأدوات القياس لتحسين تجربتك وقياس إعلاناتنا.', 'موافق', 'رفض'],
    fr: ['Nous utilisons des cookies et pixels pour améliorer votre expérience et mesurer nos publicités.', 'Accepter', 'Refuser'],
    en: ['We use cookies and tracking pixels to improve your experience and measure our ads.', 'Accept', 'Decline']
  };
  function banner() {
    if (D.getElementById('vmcConsent')) return;
    var l = D.documentElement.lang; var t = TXT[l] || TXT.ar;
    var b = D.createElement('div'); b.id = 'vmcConsent';
    b.style.cssText = 'position:fixed;bottom:0;inset-inline:0;z-index:300;background:#0B1F3B;color:#fff;padding:14px 18px;display:flex;gap:12px;align-items:center;justify-content:center;flex-wrap:wrap;font:600 14px system-ui,sans-serif;box-shadow:0 -6px 24px rgba(0,0,0,.25)';
    b.innerHTML = '<span></span><button data-y style="padding:9px 22px;border:0;border-radius:999px;background:linear-gradient(90deg,#FF3B30,#E91E63,#FF9800);color:#fff;font-weight:800;cursor:pointer"></button><button data-n style="padding:9px 18px;border:1.5px solid rgba(255,255,255,.4);border-radius:999px;background:none;color:#fff;font-weight:700;cursor:pointer"></button>';
    b.children[0].textContent = t[0]; b.children[1].textContent = t[1]; b.children[2].textContent = t[2];
    b.querySelector('[data-y]').onclick = function () { setConsent('yes'); b.remove(); loadAll(); };
    b.querySelector('[data-n]').onclick = function () { setConsent('no'); queue.length = 0; b.remove(); };
    D.body.appendChild(b);
  }

  W.VMCPixels = {
    init: function (c) {
      cfg = Object.assign({}, c || {});
      captureUTM();
      metaTag('facebook-domain-verification', cfg.verifyMeta);
      metaTag('google-site-verification', cfg.verifyGoogle);
      if (!anyPixel()) return;
      var cs = consent();
      if (cs === 'yes') loadAll(); else if (cs !== 'no') banner();
    },
    track: track,
    utm: utm
  };
})();
